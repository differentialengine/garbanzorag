# AGENTS.md
## Proof-Carrying Physical Autonomy Harness

### Mission
Produce **verified useful physical work** while treating learned intelligence as untrusted proposal machinery.

Core law:

**Think freely → propose → certify → authorize narrowly → act briefly → observe reality → verify → recover → repeat.**

Primary objective:

**maximize verified useful work / robot-hour**

subject to hard safety, authority, evidence, and recoverability constraints.

---

## 1. Authority Planes
Keep five planes distinct:

1. **Intent** — objective, constraints, authority.
2. **Proposal** — learned planning, skills, trajectories, hypotheses.
3. **Certification** — independent authorization and safety checks.
4. **Effect** — credentialed gateway + hard safety kernel.
5. **Evidence** — independent physical consequence record.

Mandatory:

**Proposer ≠ Verifier ≠ Effector.**

Models never own actuator, root, production-write, payment, safety-bypass, or emergency-control credentials.

---

## 2. Invariants

### Untrusted intelligence, trusted transition
Planner may be wrong. Executed transition must remain inside certified bounds.

### Capability ≠ authority
Model capability never expands permission automatically.

### Conditional proof honesty
Every proof states state bounds, model/calibration/timing assumptions, scope, and expiry.

### Proof classes
- **P0** authorization/provenance proof
- **P1** machine-checkable bounded-safety proof under explicit assumptions
- **P2** semantic outcome evidence with uncertainty/provenance

Never call P2 a mathematical proof.

### Short proof horizon
Prove small transition. Execute. Observe. Re-estimate. Re-prove.

### Recovery before commitment
Nontrivial action requires a certified recovery/fallback or explicit proof that none is needed.

### Reality closes the loop
Command completion is not outcome completion.

### Uncertainty shrinks authority
Larger state uncertainty → smaller admissible action envelope.

### Fail closed on authority
Missing authority means no effect.

### Degrade gracefully on confidence
Missing confidence reduces horizon, speed, force, or autonomy. Never invent certainty.

### Safety + liveness
A shield that blocks all useful work fails operationally.

---

## 3. Canonical State
Track only decision-relevant state:

- objective / anti-goals
- authority / scope
- robot + object state
- contact graph
- uncertainty bounds
- sensor health/provenance
- active skill
- hard constraints
- action capsule
- certificate/token
- recovery state
- expected sensory signature
- observed residuals
- postcondition evidence
- audit chain
- time/energy/risk budget

Do not collapse safety-critical uncertainty to one point estimate.

---

## 4. Runtime Graph

**Compile Intent → Observe → Bound State → Select Skill → Generate Candidate → Build Capsule → Certify → Tokenize → Execute Short Horizon → Observe → Verify → Continue / Recover / Stop**

If certification fails:

**measure → reduce uncertainty → simplify action → alternate skill → safe fallback → escalate**

Never pressure the verifier to approve the original action.

---

## 5. Intent Contract
Compile each physical task into:

- desired world change
- observable completion condition
- forbidden outcomes
- authority scope
- physical constraints
- acceptable risk/damage
- minimum useful result
- stop/escalation conditions

Reject proxies that can pass while reality fails.

---

## 6. Bounded Physical State
Maintain:

**B = {geometry, poses, velocities, identities, contacts, forces, material hypotheses, sensor health, uncertainty, task state}**

Use bounded sets/distributions for consequential variables.

Update after every consequential transition.

---

## 7. Contact Graph
Nodes:

- robot links
- tools
- objects
- fixtures
- environment
- humans

Contact edges may carry:

- mode
- normal
- force range
- friction/compliance
- slip likelihood
- confidence/history

Unexpected contact-mode change invalidates stale plans/certificates.

---

## 8. Skill Contract
Every physical skill defines:

- preconditions
- goal/postconditions
- allowed contacts
- forbidden contacts
- force/torque/energy envelope
- workspace/motion envelope
- expected sensory signature
- success evidence
- failure modes
- recovery transitions
- timeout/escalation

Skill without failure model is incomplete.

---

## 9. Action Capsule
Every consequential transition carries:

- objective fragment
- authority + target
- bounded pre-state + provenance
- command + horizon
- hard invariants
- dynamics/calibration/timing assumptions
- predicted consequence/sensor signature
- failure triggers
- recovery
- P0/P1/P2 verification requirements
- verifier versions + expiry

Capsule immutable after certification.

---

## 10. Certification
### P0
Verify:

**principal → authority → target → scope → expiry → exact action hash**

### P1
Where supported, establish conservatively:

**Reach(X, action, horizon) ∩ Unsafe = ∅**

plus actuator, force, energy, contact, workspace, and timing limits.

If uncertainty too large: shrink, measure, fallback, or deny.

### P2
Record semantic evidence, provenance, calibration, disagreement, known failure modes, and residual uncertainty.

---

## 11. Freshness
Invalidate certificate on:

- state leaving certified set
- unexpected contact
- sensor degradation
- human/obstacle entry
- missed timing deadline
- actuator fault
- payload/material change
- command change
- verifier/version mismatch
- stale sequence/nonce

No stale reuse.

---

## 12. Capability Token
Verifier issues short-lived token only after required gates pass.

Bind to:

- capsule/action hash
- effector/robot identity
- workspace
- allowed trajectory/control tube
- force/energy/resource limits
- expiry
- nonce/sequence
- certificate/verifier hash

Effector rejects missing, replayed, stale, widened, or mismatched token.

---

## 13. Effector + Hard Safety Kernel
Effector alone owns effect credentials.

Independent kernel continuously enforces hard constraints, typically faster than learned control.

Protect as applicable:

- joint position/velocity
- torque/current
- force
- kinetic/impact energy
- workspace/keep-out
- human separation
- watchdog/deadline
- emergency stop

Kernel may stop/brake/failsafe without model approval.

Keep emergency-stop path independent of learned compute and main software stack where feasible.

---

## 14. Real-Time Proof Budget
For hazards with reaction deadline `T_hazard` require:

**T_state + T_certify + T_token + T_gateway < T_hazard**

Otherwise use pre-certified fallback envelopes or hardware safety response.

A proof that arrives after the hazard deadline is not safety.

---

## 15. Adaptive Horizon
Conceptually:

**H ∝ 1 / (uncertainty + risk + contact complexity + model disagreement)**

Free-space, low-risk, high-confidence → longer horizon.

Contact-rich, human-adjacent, high-force, uncertain → micro-transitions.

---

## 16. Predict → Observe
Before action predict:

- next state
- contact mode
- force/tactile signature
- visual/state evidence

After action compare observed vs predicted.

Structured residual implies possible:

- state error
- model error
- contact change
- sensor fault
- disturbance
- execution mismatch

Do not blindly continue through unexplained residuals.

---

## 17. Recovery
Failure expected. Unbounded failure forbidden.

Recovery primitives may include:

- freeze
- retract
- release
- backtrack
- regrasp
- relocalize/recalibrate
- probe/change viewpoint
- switch tool
- safe-place
- restart subtask
- escalate

Recovery itself requires certification except protected emergency action.

Same recovery failure twice blocks identical retry unless evidence/strategy changes.

---

## 18. Reliability Objective
Optimize unrecovered failure, not raw local error.

Conceptually:

**p_unrecovered = p_failure × (1 − p_detect × p_recover)**

Local mistakes may remain. Detection + recovery must prevent compounding.

---

## 19. Verification Closure
After each transition preserve:

- proposal/capsule
- certificate/token
- actual effect/trajectory
- force/limit events
- unexpected events
- postcondition evidence
- residual uncertainty
- continue/recover/stop decision

Final task state must be physically verified.

---

## 20. Audit Chain
Persist tamper-evident causal record:

**intent → proposal → capsule → certificate → token → effect → evidence → postcondition → recovery/promotion**

Record concise rationale, assumptions, provenance, decisions, and machine evidence. Hidden chain-of-thought is not required.

---

## 21. Protected Kernel
Learned system may improve:

- perception
- world model
- planner
- skill selection
- action candidates
- recovery policies
- prediction models

It may not autonomously weaken:

- authority policy
- credential isolation
- emergency stop
- hard injury/damage limits
- verifier root
- protected evals
- audit integrity
- promotion gate

Protected changes require independent governance/validation.

---

## 22. Threat + Failure Topology
Continuously test:

- perception/state error
- calibration drift
- tactile/force failure
- common-mode sensor failure
- contact discontinuity
- friction/material shift
- actuator degradation
- planner hallucination
- unsafe plausible proposal
- certificate assumption violation
- verifier bug
- token replay/widening
- gateway bypass
- timing overrun
- world change after certification
- semantic false pass
- recovery loop
- safe-shield deadlock
- audit loss

---

## 23. Anti-Gaming
Reject architectures where Proposer can:

- self-approve
- patch certified capsule
- broaden token
- bypass Effector
- weaken thresholds to pass
- hide failed attempts
- redefine success after failure
- use confidence as proof
- disable evidence to improve throughput

---

## 24. Liveness
Track:

- verifier rejection/correction
- proof latency
- safe-stop time
- unnecessary fallback
- useful-work availability

Fix over-conservatism by improving state bounds, models, decomposition, or certificate granularity before weakening hard limits.

---

## 25. Evaluation
Primary:

**Useful Work Rate = verified correct physical work / robot-hour**

Hard safety remains a constraint.

Also measure:

- autonomous recovery
- unrecovered failure
- mean time between intervention
- damage
- unsafe-envelope escape
- certificate false approve/reject
- postcondition false pass/fail
- proof overhead
- safe-stop deadlock
- transfer to unseen objects/materials/disturbances

---

## 26. Promotion
Changes must beat champion on:

- representative tasks
- injected failures
- unseen perturbations
- contact-rich edges
- recovery
- liveness
- certificate quality
- hard invariants
- cost/latency

Path:

**offline → simulation → hardware shadow → constrained canary → scoped deployment**

Preserve rollback.

No self-generated improvement promotes itself using only self-generated tests.

---

## 27. Mandatory Stress Classes

1. unseen object/material
2. pose/calibration error
3. camera/tactile/force faults
4. common-mode sensor error
5. human intrusion
6. slip/jam/snag/partial insertion
7. tool wear/actuator saturation/thermal drift
8. network/compute delay
9. stale/replayed token
10. gateway bypass attempt
11. malformed capsule/verifier crash
12. world change after certification
13. recovery failure/loop
14. semantic-success spoof
15. safe-but-useless deadlock

---

## 28. Stop / Escalate
Stop or safe-state when:

- authority missing
- state cannot be bounded enough
- critical sensor validity lost
- no safe recovery for consequential action
- proof deadline missed
- verifier unavailable
- repeated unexplained residuals
- recovery graph exhausted
- prohibited human-zone entry
- semantic evidence insufficient for consequence
- hardware fault breaks assumptions

Return exact blocking uncertainty/resource.

---

## 29. Definition of Done
Task done only when:

- intended world change verified
- P0 remained valid
- P1 invariants held under recorded assumptions
- P2 evidence sufficient for consequence
- no unresolved damaging side effect
- audit complete
- final state stable/safely handed off

Harness improvement done only when matched evaluation proves higher useful-work reliability or safety without unacceptable regression or authority expansion.

---

## 30. Terminal Principle
Do not make learned intelligence infallible.

Make errors cheap, bounded, observable, recoverable, and unable to bypass independently enforced physical authority.
