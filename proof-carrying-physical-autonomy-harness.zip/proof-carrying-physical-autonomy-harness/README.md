# Proof-Carrying Physical Autonomy Harness

Files:

- `AGENTS.md` — stable constitution and runtime control law.
- `skills/physical-autonomy-orchestrator/SKILL.md` — long-horizon physical task orchestration.
- `skills/certified-action-execution/SKILL.md` — proof-carrying action capsules, tokens, effect isolation.
- `skills/failure-recovery-engineering/SKILL.md` — failure detection, recovery graphs, continuous operation.
- `skills/physical-evidence-evaluation/SKILL.md` — adversarial hardware evaluation and promotion gates.

Core law:

**Think freely → propose → certify → authorize narrowly → act briefly → observe reality → verify → recover → repeat.**
