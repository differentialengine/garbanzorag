---
name: certified-action-execution
description: Converts proposed physical or consequential agent actions into immutable proof-carrying action capsules, machine-checkable authorization and bounded-safety certificates, short-lived capability tokens, independently enforced effects, and post-execution evidence receipts. Use whenever an untrusted model proposes an effectful action with physical, financial, production, security, or irreversible consequences.
metadata:
  version: "1.0.0"
  architecture: "Proof-Carrying Action Capsule"
---
# Certified Action Execution

## Purpose
Make untrusted intelligence useful without granting it unchecked effect authority.

## 1. Required Separation
Maintain:

**Proposer ≠ Verifier ≠ Effector ≠ Recorder**

At minimum, the Proposer may not own effect credentials or certificate-signing authority.

## 2. Proof Classes
### P0 Authorization
Machine-checkable identity, authority, scope, target, expiry, and action binding.

### P1 Bounded Safety
Machine-checkable or conservatively verified invariants under explicit assumptions.

### P2 Semantic Outcome
Evidence-based claim with provenance and uncertainty.

Never merge the classes.

## 3. Action Capsule Schema
Required fields:

- action ID
- objective fragment
- principal/authority
- target
- bounded pre-state
- state evidence/provenance
- command
- horizon
- resource limits
- hard constraints
- dynamics/calibration/timing assumptions
- predicted sensory consequence
- failure triggers
- recovery
- P0/P1/P2 requirements
- verifier versions
- expiry

Incomplete capsules fail closed for consequential action.

## 4. P0 Gate
Verify:

- principal authenticated
- requested action authorized
- target in scope
- duration/resource within grant
- no privilege expansion
- expiry valid
- action hash exact

Denial must produce null effect.

## 5. P1 Gate
Where relevant check:

- reachable set vs unsafe set
- collision/contact constraints
- force/energy limits
- actuator limits
- workspace bounds
- temporal/deadline constraints
- resource ceilings
- recovery reachability

If assumptions cannot be bounded, downgrade action or deny.

## 6. Safety Assumption Contract
P1 must record every assumption capable of invalidating the certificate.

Examples:

- state set
- payload range
- friction range
- obstacle/human reachable set
- control latency
- sensor calibration
- actuator health

Certificates without assumption contracts are invalid.

## 7. Freshness Gate
Invalidate if:

- state exits certified set
- world changes materially
- unexpected contact occurs
- timing window expires
- sensor/actuator health changes
- command changes
- verifier version changes
- token sequence stale

Re-certify; never patch a signed capsule in place.

## 8. Capability Token
Issue only after required gates pass.

Bind token to:

- capsule hash
- effector
- robot/system
- exact scope
- trajectory/control tube
- force/energy/resource limits
- expiry
- nonce/sequence
- verifier identity/version

Single-use or tightly replay-protected.

## 9. Effector Contract
Effector alone holds effect credentials.

It must:

- verify token
- enforce scope
- reject command widening
- log actual effect
- stop on watchdog failure
- expose no bypass path from Proposer

## 10. Runtime Kernel
Fast independent kernel continuously enforces hard limits.

Kernel action priority:

**prevent catastrophic boundary violation > preserve hardware/object > preserve task progress**

A learned policy may not override kernel intervention.

## 11. Receding Certification
Prefer:

**certify short horizon → execute → observe → update → certify next horizon**

Do not demand global formal proof when short local guarantees are sufficient.

## 12. Postcondition Receipt
Record:

- capsule hash
- certificate/token hash
- actual effect
- actual trajectory/state transition
- hard-limit events
- P2 evidence
- residual uncertainty
- success/failure/recovery status

Receipt is immutable and audit-linked.

## 13. Semantic Evidence Rules
P2 evidence must state:

- claim
- sensor/source
- provenance
- confidence/calibration
- disagreement
- known failure modes
- validity window

Do not let the same model both invent and solely validate the evidence for high-consequence outcomes.

## 14. Threat Model
Test explicitly:

- proposer attempts direct effect
- token replay
- token scope widening
- stale certificate
- race: world changes after certification
- verifier compromise
- recorder omission
- malformed capsule
- resource exhaustion
- safety kernel timeout
- credential exfiltration
- success-criteria mutation

## 15. Bypass Test
For every effect path prove operationally:

**all credentials terminate at Effector**

and:

**no alternate path produces effect without valid authorization**

A paper policy is insufficient.

## 16. Conservative Failure
On verifier uncertainty:

- reduce horizon
- reduce energy/force
- collect measurement
- choose reversible fallback
- deny/escalate

Do not reinterpret uncertainty as permission.

## 17. Liveness Test
Track:

- false rejection
- proof latency
- safe-stop duration
- useful-work loss

If safety layer blocks useful work excessively, improve state estimation, models, decomposition, or certificate granularity before weakening invariants.

## 18. Acceptance
Action accepted only if required P0/P1 gates pass and P2 verification plan exists where semantic closure matters.

## 19. Done
Execution closes only when effect and evidence receipt are recorded, including failure or kernel intervention.
