---
name: physical-autonomy-orchestrator
description: Orchestrates long-horizon general robot manipulation using bounded belief state, contact graphs, typed physical skills, adaptive action horizons, proof-carrying execution, postcondition verification, and recovery-first control. Use for messy real-world manipulation, unknown objects, contact-rich tasks, continuous robot operation, tool use, human-adjacent manipulation, or tasks where learned policies must remain behind an independent execution boundary.
metadata:
  version: "1.0.0"
  architecture: "Proof-Carrying Physical Autonomy"
---
# Physical Autonomy Orchestrator

## Purpose
Convert a physical objective into a sequence of short, certified, observable, recoverable transitions.

Parent `AGENTS.md` owns hard authority, protected-kernel, certificate, and audit invariants.

## 1. Compile Task
Produce:

**objective → observable success → anti-goals → constraints → authority → minimum useful result → stop conditions**

Do not optimize a proxy that can pass while the physical outcome fails.

## 2. Establish Bounded State
Build:

- robot state
- object hypotheses
- geometry/workspace
- contacts
- force/torque state
- human/obstacle state
- sensor health
- uncertainty set
- task phase

Use bounded variables for safety-critical quantities.

## 3. Build Contact Graph
Track expected and actual contacts between:

- robot links
- gripper/tool
- manipulated objects
- fixtures
- environment
- humans

Unexpected contact-mode transition triggers re-estimation or stop.

## 4. Select Skill
Skill must define:

- preconditions
- postconditions
- allowed/forbidden contacts
- motion/force envelope
- sensory signature
- failure modes
- recovery states

Reject a skill whose preconditions cannot be established.

## 5. Candidate Generation
Generate several materially different short-horizon actions when uncertainty matters.

Use learned intelligence for:

- semantic decomposition
- trajectory proposals
- contact hypotheses
- tool selection
- recovery ideas

Do not let proposal ranking bypass certification.

## 6. Adaptive Horizon
Shrink horizon with:

- uncertainty
- contact complexity
- model disagreement
- human proximity
- force/energy
- reversibility cost

Prefer micro-transitions in contact-rich phases.

## 7. Predict Sensory Consequence
For each serious candidate predict:

- state transition
- contact mode
- force/tactile signature
- visual change
- failure indicators

Predictions exist to detect model error, not to declare success.

## 8. Compile Action Capsule
Send candidate to `certified-action-execution` with:

- bounded pre-state
- command/horizon
- hard constraints
- assumptions
- expected evidence
- recovery
- verification requirements

## 9. Execute One Certified Transition
No valid token, no actuation.

Observe continuously.

If hard kernel intervenes, treat it as a failure event and re-estimate.

## 10. Compare Prediction vs Reality
Compute decision-relevant residuals.

Classify:

- expected
- benign deviation
- model mismatch
- state-estimation failure
- unexpected contact
- hardware/sensor degradation
- external disturbance

Do not average away structured anomalies.

## 11. Verify Postcondition
Use independent physical evidence proportional to consequence.

Examples:

- insertion depth + tactile latch + pull test
- grasp pose + tactile stability + load response
- drawer position + handle release + visual confirmation

Multiple correlated sensors are not automatically independent.

## 12. Continue / Recover / Stop
### Continue
Postcondition sufficient; next state remains bounded.

### Recover
Failure detected but recovery graph contains a certified path.

### Stop
Safety, authority, state bounds, or recovery guarantees insufficient.

## 13. Long-Horizon Strategy
Never plan the entire long task as an irreversible trajectory.

Use:

**task graph → skill → certified transition → evidence → graph update**

Replan from actual state, not intended state.

## 14. Unknown Object Protocol
For unfamiliar objects:

1. inspect
2. estimate geometry/material/contact affordances
3. perform low-energy probe if needed
4. update friction/compliance hypotheses
5. choose reversible manipulation
6. increase commitment only after evidence

Do not infer safe force solely from visual category.

## 15. Human-Adjacent Protocol
When a human is in reachable space:

- tighten speed/energy bounds
- shorten horizon
- maintain human reachable-set estimate
- prefer predictable motions
- guarantee independent stop path

Semantic intent does not override injury limits.

## 16. Contact-Rich Protocol
For insertion, cables, deformables, wiping, fastening, or constrained motion:

- use tactile/force evidence
- track contact graph
- maintain force envelopes
- detect jam/slip early
- use compliant/reversible search
- avoid long open-loop motion

## 17. Reliability Objective
Optimize:

**verified useful work / robot-hour**

not raw single-shot success.

Track:

- intervention frequency
- recovery success
- repeated failure
- task latency
- damage
- certificate rejection

## 18. Anti-Patterns
Reject:

- end-to-end VLA → actuator
- long blind action chunks
- visual-only contact decisions when tactile evidence is available
- success inferred from command completion
- repeated recovery without changed evidence
- increasing force because planner confidence increased
- silently expanding workspace or contact permissions

## 19. Output
For substantial actions provide internal structured state equivalent to:

- objective
- state bounds
- skill
- candidate
- capsule status
- certificate result
- execution result
- postcondition evidence
- recovery/continue decision
- residual uncertainty

## 20. Done
Task completes only when real physical outcome is verified and system ends in a stable, safe state.
