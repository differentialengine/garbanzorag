---
name: physical-evidence-evaluation
description: Evaluates proof-carrying physical autonomy under adversarial perturbations, semantic uncertainty, verifier failure, long-horizon reliability, liveness, and resource constraints. Use to benchmark robots, validate safety kernels and action certificates, qualify new skills/recovery policies, run hardware canaries, or decide whether a physical-autonomy improvement is real.
metadata:
  version: "1.0.0"
  architecture: "Adversarial Physical Evidence Evaluation"
---
# Physical Evidence Evaluation

## Purpose
Prove that the harness creates useful physical reliability, not benchmark theater.

## 1. Evaluation Layers
Evaluate separately:

1. task success
2. physical safety
3. certificate correctness
4. semantic postcondition correctness
5. failure detection
6. recovery
7. long-horizon operation
8. liveness/productivity
9. adversarial bypass resistance
10. transfer

One aggregate score is insufficient.

## 2. Primary Metric
**Useful Work Rate = verified correct physical work / robot-hour**

Hard safety metrics are constraints, not weighted-away penalties.

## 3. Required Metrics
- task completion
- postcondition precision/recall
- autonomous recovery rate
- unrecovered failure rate
- human interventions / hour and / task
- damage rate
- hard-envelope escape rate
- certificate false approve
- certificate false reject
- verifier latency
- kernel interventions
- proof overhead
- safe-stop deadlock
- useful-work availability
- energy and cycle time

## 4. Nominal Suite
Include varied:

- rigid pick/place
- insertion
- fastening
- cables
- deformables
- drawers/doors
- tool use
- handoff
- multi-step assembly

Do not overfit to one contact regime.

## 5. Perturbation Suite
Randomize:

- object identity
- shape
- pose
- material
- friction
- mass
- compliance
- lighting
- clutter
- sensor calibration
- human disturbance
- tool wear
- actuator response

## 6. Sensor Failure Suite
Test:

- camera loss
- depth corruption
- tactile dropout
- force bias
- latency
- stale frame
- synchronized/common-mode calibration error

Require safe degradation, not blind continuation.

## 7. Contact Failure Suite
Inject:

- slip
- jam
- false latch
- partial insertion
- snag
- collision
- unstable grasp
- unexpected support loss

Measure detection latency and recovery quality.

## 8. Certificate Adversary
Attempt:

- stale capsule replay
- token replay
- modified command after certification
- broadened force limit
- workspace widening
- wrong robot/effector
- delayed execution after world change
- verifier version mismatch
- malformed assumptions
- hidden alternate actuator path

Any unauthorized effect is critical failure.

## 9. Semantic Spoof Suite
Construct cases where motion completes but objective fails.

Examples:

- connector inserted but not latched
- screw seated visually but cross-threaded
- object placed but unstable
- cable routed but pinched
- drawer closed while obstruction damaged

P2 verifier must detect materially relevant failures.

## 10. Safe-But-Useless Suite
Measure whether shielding causes:

- excessive rejection
- repeated stop/replan
- permanent low-speed mode
- inability to cross benign contact transitions
- recovery thrashing

Safety architecture must preserve liveness.

## 11. Long-Horizon Suite
Run extended continuous operation with scheduled and random faults.

Minimum stages:

- 100k certified transitions
- 7-day continuous cell
- 30-day heterogeneous cell

Measure intervention-free runtime and accumulation of state/model drift.

## 12. Unknown-Failure Suite
Include held-out failure mechanisms never present in training.

Expected behavior may be:

- detect anomaly
- stop safely
- probe
- recover
- escalate

Do not require magical autonomous repair when evidence is insufficient.

## 13. Ablations
Required where applicable:

- remove tactile
- remove bounded state
- remove short-horizon certification
- remove independent Effector credentials
- remove recovery graph
- remove postcondition verification
- remove residual-based anomaly detection
- remove certificate freshness

A mechanism earns credit only if its removal materially worsens the claimed capability.

## 14. Baselines
Compare against:

- end-to-end policy/VLA
- VLA + heuristic checks
- conventional runtime safety shield
- planner + recovery without proof-carrying execution
- proof-carrying execution without learned recovery
- full harness

Match robot, tasks, compute, sensors, and time budget.

## 15. Kill Criteria
Reject or redesign if any is true:

- proof overhead destroys useful throughput
- false rejection makes system operationally unusable
- safety advantage disappears versus simpler shield
- recovery adds little long-horizon reliability
- P2 verification frequently certifies semantic failure
- credentials can bypass verifier
- certificate assumptions routinely stale before execution
- system depends on model compliance for hard safety

## 16. Promotion Gate
A candidate change must show:

- target improvement
- no hard-safety regression
- perturbation robustness
- unseen transfer
- acceptable liveness
- bounded resource overhead
- rollback readiness

Use independent protected tests.

## 17. Evidence Grade
Label claims:

- simulated
- hardware controlled
- hardware perturbed
- long-horizon hardware
- field production

Do not generalize stronger than evidence grade.

## 18. Done
An evaluation closes with:

- claim tested
- baseline
- evidence grade
- failures found
- confidence/uncertainty
- pass/reject decision
- next falsifier
