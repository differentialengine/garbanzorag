---
name: failure-recovery-engineering
description: Designs and executes failure detection, fault isolation, recovery graphs, perturbation handling, and continuous-operation strategies for robots and agentic physical systems. Use when long-horizon reliability matters more than single-shot success, when contact-rich tasks can jam/slip/drift, or when systems must autonomously return from broken states without repeated unsafe retries.
metadata:
  version: "1.0.0"
  architecture: "Failure-Normal Physical Autonomy"
---
# Failure Recovery Engineering

## Purpose
Make local mistakes cheap, observable, and recoverable so they do not compound into mission failure.

## 1. Reliability Model
Track separately:

- local failure probability
- detection probability
- recovery probability
- unrecovered failure probability
- damage probability
- human-intervention probability

Primary goal: reduce **unrecovered** failures.

## 2. Failure Taxonomy
At minimum classify:

### State failures
- pose drift
- wrong object identity
- stale world state

### Contact failures
- slip
- jam
- missed contact
- unexpected contact
- excessive preload

### Perception failures
- occlusion
- lighting
- depth corruption
- tactile dropout
- force bias

### Hardware failures
- actuator saturation
- backlash/wear
- thermal degradation
- gripper fault

### Planning failures
- infeasible skill
- wrong precondition
- bad tool choice
- dead-end configuration

### Verification failures
- false semantic pass
- sensor correlation
- stale certificate

### Recovery failures
- repeated retry
- recovery causes new failure
- no stable fallback state

## 3. Failure Detection
Use disagreement between:

- predicted and actual motion
- predicted and actual force/tactile
- redundant sensing with different failure paths
- task invariants
- timing/resource expectations

Confidence alone is not detection.

## 4. Failure Event
When threshold crossed:

1. stop unsafe progression
2. preserve physical state if possible
3. snapshot evidence
4. classify recoverability
5. choose certified recovery
6. verify recovery result

## 5. Recovery Graph
Represent recoveries as explicit state transitions.

Example:

**jammed insertion → retract → relocalize → orientation correction → low-force probe → retry**

Each edge has:

- preconditions
- safety envelope
- success evidence
- timeout
- next alternative

## 6. Recovery Preference
Prefer in order where appropriate:

1. freeze
2. low-energy retract
3. release/load removal
4. return to last verified state
5. relocalize/recalibrate
6. alternate grasp/tool/approach
7. safe-place object
8. human escalation

Do not preserve task progress at the expense of bounded safety.

## 7. Anti-Loop
After the same failure twice:

- identical retry prohibited
- update causal hypothesis
- change state evidence, approach, tool, force strategy, or abstraction

After repeated low-information failures, exit task graph to safe state.

## 8. Recovery Certification
Recovery is still an effectful physical action.

Use `certified-action-execution` for all consequential recovery transitions.

Emergency kernel actions remain separately protected.

## 9. Failure Memory
Persist only useful abstractions:

- failure signature
- causal evidence
- successful recovery
- validity scope
- counterexamples
- invalidation conditions

Do not turn one anecdotal failure into global policy.

## 10. Fault Injection
Training/evaluation should deliberately inject:

- pose error
- friction shift
- mass shift
- tactile loss
- force bias
- camera occlusion
- partial insertion
- snag
- human disturbance
- tool wear
- actuator slowdown
- communication delay
- calibration drift

Recovery capability trained only on clean demonstrations is incomplete.

## 11. Unknown Failure Protocol
When failure does not match known class:

1. stop progression
2. bound physical state
3. collect minimally invasive evidence
4. generate competing mechanisms
5. test cheapest discriminator
6. select only reversible recovery
7. escalate if state cannot be bounded

## 12. Damage Containment
Before recovery ask:

- can object be made safe?
- can stored energy be removed?
- can tension/preload be released?
- can human exposure be eliminated?

Containment may dominate task completion.

## 13. Continuous Operation Metrics
Track:

- mean time between interventions
- autonomous recovery rate
- mean recovery time
- repeat-failure rate
- recovery-induced damage
- percent useful-work uptime
- unresolved-failure rate

## 14. Promotion
A new recovery policy must beat baseline on:

- target failure
- adjacent failures
- unseen perturbations
- safety
- time/cost
- no new loops

Shadow/canary before broad use.

## 15. Done
Recovery ends only when the system reaches a verified task-valid state, a verified safe terminal state, or an explicit escalation state.
