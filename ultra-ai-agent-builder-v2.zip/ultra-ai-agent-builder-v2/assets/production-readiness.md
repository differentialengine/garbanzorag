# Production Readiness Gate

## Outcome
- [ ] User outcome is measurable.
- [ ] Acceptance tests map to requirements.
- [ ] Non-goals are explicit.

## Architecture
- [ ] Minimal viable agent architecture is justified.
- [ ] State is explicit.
- [ ] Component contracts are typed.
- [ ] Stop conditions exist.

## Tools and authority
- [ ] Least privilege enforced.
- [ ] Material side effects are independently verified.
- [ ] Irreversible operations are gated.
- [ ] Secrets remain isolated.
- [ ] External/repository content cannot redefine authority.

## Evals
- [ ] Development evals pass.
- [ ] Hidden evals pass threshold.
- [ ] Adversarial evals pass.
- [ ] Regression suite passes.
- [ ] Evaluator integrity checked.
- [ ] Reward-hacking paths tested.

## Reliability
- [ ] Retries are bounded.
- [ ] Idempotency defined where needed.
- [ ] Timeouts defined.
- [ ] Backpressure/circuit breakers defined.
- [ ] Fallback/degraded mode tested.
- [ ] Rollback tested.

## Observability
- [ ] Structured tracing exists.
- [ ] Cost per verified success tracked.
- [ ] Failure taxonomy emitted.
- [ ] Calibration measurable.
- [ ] Alerts defined.

## Production
- [ ] Shadow tested.
- [ ] Canary tested.
- [ ] SLOs defined.
- [ ] Load/concurrency tested.
- [ ] Drift monitored.
- [ ] Incident runbook tested.

## Self-improvement
- [ ] Changes require baseline comparison.
- [ ] Hidden/regression eval gates exist.
- [ ] Authority cannot self-expand.
- [ ] Rollback exists.

## Release
Release only when critical items above are evidenced, not merely checked by assertion.
