# Agent Incident Runbook

## Contain

Disable risky mutations or switch the affected agent/task class to read-only mode.

## Preserve evidence

Capture task IDs, state versions, policy decisions, tool calls, operation IDs, evidence IDs, verifier results, model/provider versions, and deployment version.

## Restore

Rollback to the latest known-good runtime, model configuration, tool contract, or policy version.

## Diagnose

Classify the first bad assumption using REQ/OBS/CTX/LOC/CAU/PLN/TOL/IMP/VER/SEC/ECO/COO/NOV/MEM.

## Prevent recurrence

Create the regression case before or alongside the fix.

## Re-release

Run hidden, adversarial, regression, security, cost, and latency gates. Deploy through canary. Monitor the exact failure signal that caused the incident.
