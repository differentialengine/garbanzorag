# Ultra AI Agent Builder v2

A production-oriented Agent Skills package for building AI agents as measured, bounded, self-correcting control systems rather than prompt wrappers.

The package contains three layers:

```text
SKILL.md     execution controller and mandatory gates
references/  detailed implementation/eval/production protocols
examples/    runnable reference agent showing the contracts in code
```

## Scaffold a new agent

```bash
python scripts/scaffold_agent.py ./my-agent --with-reference-runtime
```

## Validate the skill

```bash
python scripts/validate_skill.py .
```

## Validate an agent package

```bash
python scripts/validate_agent_package.py ./my-agent
```

## Run the reference implementation

```bash
cd examples/reference_agent
python -m unittest discover -s tests -v
python run_demo.py
```

The reference runtime is intentionally provider-independent. Replace its deterministic planner with an LLM-backed planner only after preserving the typed state, policy gate, tool contracts, verification boundary, budget limits, telemetry, and terminal-state semantics.
