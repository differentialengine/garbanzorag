# Agent Architecture Patterns

## Pattern selection law

Use the least complex architecture that can meet the verified outcome.

## Deterministic workflow

Use when steps and branches are enumerable.

Benefits:
- predictable
- cheap
- easy to test

## Single agent + tools

Use when action selection depends on context but one coherent state is sufficient.

Keep:
- explicit state
- bounded tools
- independent verifier

## Planner + executor

Use when long-horizon decomposition materially improves execution.

Planner outputs structured milestones.
Executor cannot silently redefine the objective.
Re-plan when evidence invalidates assumptions.

## Candidate + critic + judge

Use when generation and falsification benefit from separation.

Candidate proposes.
Critic attacks.
Judge uses evidence and predefined criteria.

The judge must not reward rhetoric.

## Specialist agents

Use when domains require meaningfully distinct context or tools.

Examples:
- security
- database
- observability
- legal/compliance review

## Parallel hypothesis agents

Use when independent hypotheses can be explored simultaneously.

Merge evidence, not merely conclusions.

## Supervisor pattern

Use when multiple agents share a goal but require centralized budget, state, and authority control.

Supervisor owns:
- task state
- budgets
- authority
- conflict resolution
- final verification

## Anti-pattern: agent swarm

Do not create many agents that:
- repeat the same reasoning
- vote without independent evidence
- inflate token usage
- obscure accountability

## Anti-pattern: unbounded planner

A planner must have:
- milestone limit
- cost budget
- stop criteria
- state checkpoints

## Anti-pattern: self-grading loop

Do not allow:
```text
generate → ask same system whether good → accept
```

Use external behavior, deterministic checks, or meaningfully independent verification.
