# Build Contract

## Purpose

Convert vague agent requests into an executable product contract before architecture or implementation.

## Outcome model

Write the outcome as an externally observable state transition:

```text
given context X
when event/request Y occurs
the system produces action/result Z
and evidence E demonstrates that Z is correct
within constraints C
```

Avoid capability labels such as "smart", "autonomous", "world-class", or "reliable" unless each is decomposed into measurable behavior.

## Requirement classes

For every request extract:

- outcome requirements
- quality requirements
- latency requirements
- cost requirements
- privacy/security requirements
- authority constraints
- availability requirements
- scale/concurrency requirements
- recoverability requirements
- observability requirements
- regulatory/compliance requirements where applicable

## Acceptance-test mapping

Create a bidirectional map:

```text
Requirement → acceptance test
Acceptance test → requirement
```

A requirement without a test is a risk.
A test without a requirement may be waste.

## Non-goals

Explicitly state what the agent must not optimize or attempt.

Examples:

- no unrestricted browser actions
- no direct production deletion
- no persistent memory of sensitive content
- no autonomous external messaging
- no online model training

## Required artifacts

A production build should normally contain:

```text
AGENT_SPEC.yaml
AGENTS.md
architecture.md
policies/authority.yaml
evals/eval-plan.yaml
evals/regression/
observability.md
production-readiness.md
proof-packet.yaml
```

## Assumption register

Every inferred assumption has:

```yaml
assumption:
  claim: ""
  evidence: []
  impact_if_wrong: low|medium|high|critical
  validation_method: ""
  status: open|validated|rejected
```

Validate high-impact assumptions early.

## Binding constraint

At each milestone identify one primary constraint on verified progress.

Do not optimize non-bottlenecks because they are easy to improve.
