# 14. Production Cookbook

## SLOs

Define outcome SLOs, not only infrastructure uptime.

Example:

```text
99% routine tasks reach VERIFIED within 5 s
false-success rate < 0.2%
99.9% policy checks < 20 ms
authority violations = 0
```

## Concurrency

Use bounded queues and explicit backpressure.

```text
incoming tasks
→ bounded queue
→ worker pool
→ per-tenant concurrency limit
→ downstream rate limiter
```

When the queue is full, reject/defer explicitly. Do not allow unbounded memory growth.

## Timeout hierarchy

Ensure child timeouts are shorter than parent deadlines.

```text
request deadline 10s
planner budget 2s
tool budget 4s
verifier budget 2s
response reserve 2s
```

## Circuit breakers

For unstable dependencies:

```text
closed → normal calls
open → fail fast/degraded mode
half-open → limited probes
```

The agent should receive dependency state as structured context, not rediscover the outage through repeated failing calls.

## Rollout

```text
offline → integration → shadow → canary → limited → full
```

Shadow mode observes and proposes but cannot mutate.

Canary should use a small authority/resource scope, not merely a small percentage of requests if one request could have huge blast radius.

## Rollback triggers

Immediate rollback:

```text
authority violation
secret exposure
unexpected destructive action
evaluator compromise
catastrophic false success
```

Threshold rollback:

```text
verified success regression
cost explosion
p95 latency regression
recovery-rate decline
```

## Drift

Track:

```text
model version
tool schema
API dependency behavior
task distribution
user behavior
cost
latency
eval score
failure topology
```

Version changes should trigger targeted regression suites automatically.

## Incident response

```text
contain
preserve evidence
restore known-good state
classify failure
reproduce offline
add regression
repair
rerun hidden/adversarial suite
canary
monitor exact failure metric
```
