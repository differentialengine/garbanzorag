# Failure Taxonomy and Recovery

## Categories

```text
REQ requirement misunderstanding
CTX missing or misleading context
OBS bad observation/state
LOC wrong localization
CAU incorrect causal model
PLN bad plan
IMP implementation defect
TOL tool failure
VER verifier/eval defect
SEC safety/authority failure
ECO cost/latency failure
COO coordination failure
NOV novelty/distribution shift
MEM memory corruption/staleness
```

## Diagnosis

For every material failure record:

```yaml
symptom: ""
category: ""
first_bad_assumption: ""
evidence: []
blast_radius: ""
recovery: ""
preventive_change: ""
regression_test: ""
```

## Retry control

First failure:
- inspect error
- decide transient vs structural

Second materially similar failure:
- force strategy change

Third:
- perform meta-review:

```text
Is the requirement wrong?
Is the observation wrong?
Is localization wrong?
Is the causal model wrong?
Is the tool unreliable?
Is the verifier wrong?
Is the task infeasible under current authority?
```

## Recovery

Prefer recovery that restores a known-good state before experimentation.

## Learning requirement

A serious failure is not closed until one or more exist:

- regression test
- invariant
- detector
- tool contract improvement
- policy
- corrected model
- routing change
