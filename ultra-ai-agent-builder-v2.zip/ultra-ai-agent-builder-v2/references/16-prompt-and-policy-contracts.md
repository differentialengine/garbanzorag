# 16. Prompt and Policy Contracts

A production agent prompt should define decision procedure and output contract. It should not be used as the only safety boundary.

## Runtime system-instruction template

```markdown
# Role
You are the decision component inside <agent-name>. You do not directly possess authority. You propose typed observations or actions to the runtime.

# Outcome
<observable user outcome>

# Hard constraints
<requirements that may not be violated>

# Current state
The runtime will provide structured task state, evidence references, uncertainty, budgets, and available tools.

# Decision procedure
1. Identify the current binding uncertainty.
2. Maintain competing hypotheses when more than one explanation remains plausible.
3. Prefer the reversible action that most reduces decision-relevant uncertainty per unit of cost/risk.
4. Do not infer a side effect from a tool acknowledgement. Require observed post-action state.
5. If evidence contradicts the current explanation, revise the explanation.
6. Do not repeat a failed action unless new information or changed state justifies it.
7. Stop when the acceptance conditions are verified or when safe progress is blocked.

# Authority
You may only propose tools supplied by the runtime. Tool availability does not imply authorization. Runtime policy is authoritative. Never attempt to alter, evade, or reinterpret authorization policy.

# Evidence discipline
Label conclusions as supported, contradicted, unresolved, or inferred. Never fabricate tool output, test results, source content, state transitions, or verification.

# Output
Return only an object matching the provided decision schema.
```

The runtime should inject task-specific state separately rather than rewriting the permanent policy for every turn.

## Decision schema example

```json
{
  "binding_uncertainty": "causal",
  "hypothesis_updates": [
    {
      "id": "H1",
      "status": "supported",
      "evidence_ids": ["E12"]
    }
  ],
  "next_action": {
    "type": "tool",
    "name": "read_dependency_health",
    "arguments": {"service_id": "svc-17"},
    "why_this_action": "distinguishes H1 from H2 without mutation"
  },
  "stop": false
}
```

`why_this_action` is an auditable rationale, not hidden chain-of-thought. Keep it concise and tied to evidence/decision value.

## Tool description writing

Bad:

```text
restart_service: Restarts a service.
```

Good:

```text
restart_service(service_id, operation_id)
Purpose: Restart exactly one service instance after a local-fault diagnosis.
Side effect: temporary unavailability of that instance.
Requires: service.restart.single permission and an idempotency operation_id.
Do not call: for dependency faults, unknown target identity, or without fresh health evidence.
Success response: acknowledges command acceptance only. It does NOT prove recovery.
Required follow-up: read_health(service_id) and independent verifier pass.
```

Good tool descriptions teach the decision boundary, not only API syntax.

## Planner prompt vs verifier prompt

Do not use the same objective wording when it creates correlated bias.

Planner:

```text
Find the best next observation or action for achieving the outcome.
```

Verifier:

```text
Assume the proposed result may be wrong. Determine whether the externally observable acceptance conditions are actually satisfied using supplied evidence only. Return unresolved when evidence is insufficient.
```

The verifier should receive acceptance criteria and evidence, not the planner's persuasive narrative when that narrative is unnecessary.

## Critic prompt

```text
Attempt to falsify the candidate by finding a violated requirement, unsupported assumption, missing edge case, unsafe authority expansion, false-success path, or cheaper discriminating test that was skipped. Return concrete counterexamples or evidence requests, not stylistic critique.
```

## Memory-writing prompt

A model can propose memory, but deterministic code decides persistence.

```json
{
  "claim": "dependency X exhibited 30s eventual consistency",
  "evidence_ids": ["E4", "E8"],
  "scope": "staging-us-east",
  "suggested_confidence": 0.8,
  "suggested_expiry": "..."
}
```

The memory store rejects the proposal if it lacks provenance, contains secrets, or is not verified enough for the selected memory class.

## Prompt anti-patterns

Avoid:

```text
"Think as hard as possible"
"Be superintelligent"
"Never fail"
"Use as many agents as needed"
"Keep trying until solved"
```

These do not define runtime behavior and can encourage unbounded cost or false confidence.

Replace them with explicit state, budgets, verification, action selection, and termination rules.
