# Production and Scale

## Deployment path

```text
offline eval
→ integration
→ shadow
→ canary
→ limited rollout
→ monitored rollout
→ full rollout
```

Each promotion requires explicit acceptance thresholds.

## Reliability design

Define:

- SLOs
- error budget
- timeout hierarchy
- retry limits
- idempotency keys
- rate limits
- concurrency limits
- backpressure
- circuit breakers
- queue semantics
- cache policy
- degraded mode
- fail-open/fail-closed rules
- data retention
- rollback

## State

Explicitly decide:

- stateless vs stateful
- session lifetime
- persistence
- consistency requirements
- concurrent writes
- stale-state detection
- versioning
- checkpointing

## Multi-tenant systems

Require:

- tenant isolation
- credential isolation
- per-tenant rate limits
- data partitioning
- audit boundaries
- abuse controls
- cost attribution

## Drift

Monitor drift in:

```text
requirements
world/data distribution
model behavior
tool behavior
dependencies
cost
latency
security posture
evaluation distribution
```

A previously verified system may become invalid.

## Incident mode

For severe failure:

```text
contain
→ preserve evidence
→ stop autonomous expansion
→ establish current state
→ measure blast radius
→ restore safe baseline
→ diagnose
→ test offline
→ redeploy narrowly
→ add regression
```

## Capacity planning

Load-test:

- concurrent sessions
- tool bottlenecks
- model-rate limits
- queue depth
- memory growth
- context growth
- retry storms
- downstream dependency failure

## Production proof

Production readiness requires evidence for:

```text
functional correctness
fault tolerance
security boundaries
load behavior
cost envelope
rollback
observability
incident recovery
```
