# Observability, Routing, and Economics

## North-star operational metrics

Track:

```text
verified success rate
cost per verified success
p50/p95 time to verified success
retry rate
escalation rate
verification coverage
calibration error
catastrophic failure rate
recovery success rate
rollback rate
authority-denial rate
```

## Structured events

Each meaningful step emits:

```yaml
timestamp: ""
task_id: ""
phase: ""
component: ""
action: ""
hypothesis_id: ""
tool: ""
cost: 0
latency_ms: 0
evidence_added: []
uncertainty_delta: {}
verifier_result: ""
failure_category: null
status: ""
```

## Total cost

Optimize:

```text
inference
+ tool usage
+ infrastructure
+ latency
+ retries
+ verification
+ recovery
+ human intervention
+ expected failure loss
```

Cheap inference that causes expensive recovery is not cheap.

## Routing

Maintain empirical capability registry by task class.

Use:

```text
task capability demand
× measured component reliability
× expected total cost
× latency
× failure consequence
```

Do not permanently hardcode "small model for easy, big model for hard".

## Escalation

Preferred escalation order is often:

```text
better observation
→ better context
→ better tool
→ better decomposition
→ stronger model
→ independent specialist
→ human authority if required
```

## Budget controls

Every autonomous loop needs:

- token budget
- tool-call budget
- elapsed-time budget
- retry cap
- escalation cap
- external side-effect cap

Budget exhaustion produces a defined state, not silent degradation.

## Calibration

Compare predicted confidence with observed success.

Overconfidence should trigger:

- stronger verification
- lower autonomy
- better uncertainty modeling
- targeted regression tests
