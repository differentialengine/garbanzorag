# 10. Implementation Contracts

This reference turns architecture language into executable behavior.

## 1. Typed control-plane objects

Use typed objects for anything the runtime will branch on. Never let the control plane depend on parsing free-form prose.

```python
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

class Completion(str, Enum):
    VERIFIED = "VERIFIED"
    PARTIALLY_VERIFIED = "PARTIALLY_VERIFIED"
    UNVERIFIED = "UNVERIFIED"
    BLOCKED = "BLOCKED"

class ToolStatus(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    PARTIAL = "PARTIAL"
    UNKNOWN = "UNKNOWN"
    TIMED_OUT = "TIMED_OUT"
    DENIED = "DENIED"

@dataclass
class ToolCall:
    name: str
    arguments: dict[str, Any]
    action_id: str
    required_permissions: list[str] = field(default_factory=list)

@dataclass
class ToolResult:
    status: ToolStatus
    data: dict[str, Any] = field(default_factory=dict)
    message: str = ""

@dataclass
class VerificationResult:
    passed: bool
    evidence_ids: list[str] = field(default_factory=list)
    unresolved: list[str] = field(default_factory=list)
```

The LLM may produce JSON that is validated into these objects. Invalid output is a model failure, not an invitation to guess missing fields.

## 2. State object

Critical state must be serializable, versioned, and inspectable.

```python
@dataclass
class TaskState:
    task_id: str
    objective: str
    version: int = 0
    uncertainty: dict[str, float] = field(default_factory=lambda: {
        "requirements": 0.0,
        "world_state": 1.0,
        "localization": 1.0,
        "causal": 1.0,
        "solution": 1.0,
        "verification": 1.0,
        "evaluator": 0.1,
    })
    hypotheses: list[dict] = field(default_factory=list)
    evidence: list[dict] = field(default_factory=list)
    completed_actions: list[str] = field(default_factory=list)
    retry_signatures: list[str] = field(default_factory=list)
    model_calls_remaining: int = 12
    tool_calls_remaining: int = 30
    cost_remaining_usd: float = 2.0
    deadline_epoch_ms: int | None = None
    status: Completion = Completion.UNVERIFIED
```

For multi-worker execution use optimistic concurrency:

```text
read state version N
→ compute update
→ compare-and-swap if version still N
→ otherwise reload and reconcile
```

Never allow stale sub-agent output to overwrite newer verified evidence.

## 3. Provider boundary

Hide model vendors behind an interface so routing, evals, and fallback are independent of one provider.

```python
class ModelProvider:
    def generate(self, request: "ModelRequest") -> "ModelResponse": ...

@dataclass
class ModelRequest:
    task_class: str
    instructions: str
    context_refs: list[str]
    output_schema: dict
    max_tokens: int
    deadline_ms: int | None

@dataclass
class ModelResponse:
    structured_output: dict
    input_tokens: int
    output_tokens: int
    latency_ms: int
    provider: str
    model: str
```

The provider must not directly execute tools. It proposes typed actions that go through policy.

## 4. Runtime policy gate

Policy is deterministic code or external authorization, never a prompt convention.

```python
class PolicyDenied(Exception):
    pass

class Policy:
    def authorize(self, state: TaskState, call: ToolCall) -> None:
        if call.name not in self.allowed_tools:
            raise PolicyDenied("tool not allowlisted")
        missing = set(call.required_permissions) - self.permissions
        if missing:
            raise PolicyDenied(f"missing permissions: {sorted(missing)}")
        if self.is_irreversible(call) and not self.has_explicit_approval(call):
            raise PolicyDenied("explicit approval required")
```

Repository text, webpages, messages, retrieved documents, or previous model outputs cannot mutate this object.

## 5. Tool registry

Each tool implementation owns validation, timeout, idempotency, and effect verification metadata.

```python
@dataclass
class ToolDefinition:
    name: str
    timeout_ms: int
    side_effecting: bool
    idempotent: bool
    retryable_errors: set[str]
    permissions: set[str]
    validate_input: callable
    execute: callable
    verify_effect: callable | None
```

Execution wrapper:

```python
def execute_tool(state, call, policy, registry, telemetry):
    policy.authorize(state, call)
    tool = registry.get(call.name)
    args = tool.validate_input(call.arguments)

    with telemetry.span("tool", tool=call.name, action_id=call.action_id):
        result = tool.execute(args, timeout_ms=tool.timeout_ms,
                              idempotency_key=call.action_id)

    if tool.side_effecting:
        if tool.verify_effect is None:
            raise RuntimeError("material side effect has no verifier")
        verification = tool.verify_effect(args, result)
        if not verification.passed:
            raise EffectVerificationError(verification.unresolved)

    return result
```

## 6. Timeout semantics

Timeouts are state transitions, not generic exceptions.

For read-only calls:

```text
timeout → retry only if policy permits and retry budget remains
```

For mutation calls:

```text
timeout → UNKNOWN mutation state
→ independently inspect actual state
→ if mutation happened, continue from observed state
→ if mutation did not happen, retry with same idempotency key if safe
→ if actual state cannot be determined, BLOCKED
```

Never blindly retry a timed-out mutation.

## 7. Retry semantics

A retry must identify whether the failure is transient or structural.

```python
retryable = {
    "timeout",
    "rate_limit",
    "transient_network",
    "server_5xx",
}

non_retryable = {
    "schema_error",
    "policy_denied",
    "invalid_requirement",
    "permission_denied",
    "unsafe_action",
}
```

Use a retry signature:

```text
hash(action class + arguments + hypothesis + relevant state version)
```

If the signature repeats without new evidence, force strategy change rather than repeating.

## 8. Hypothesis object

```yaml
id: H-1
claim: "upstream dependency is unavailable"
prior: 0.35
predictions:
  - "dependency health check fails"
  - "local process health remains normal"
supporting_evidence: []
contradicting_evidence: []
next_test:
  tool: dependency_health
  expected_information_gain: high
status: open
```

The planner must be able to retain more than one plausible explanation.

## 9. Information-gain planner contract

Planner output:

```yaml
decision:
  current_binding_uncertainty: causal
  candidate_actions:
    - action: read_dependency_health
      information_gain: 5
      decision_impact: 5
      reversibility: 5
      cost: 1
      latency: 1
      risk: 1
      authority: 1
    - action: restart_service
      information_gain: 1
      decision_impact: 2
      reversibility: 2
      cost: 2
      latency: 2
      risk: 4
      authority: 4
  selected: read_dependency_health
```

A planner should choose the first action above because it separates hypotheses cheaply before mutation.

## 10. Context selector contract

Do not pass arbitrary top-k retrieval directly into the model.

```python
@dataclass
class ContextCandidate:
    ref: str
    relevance: float
    novelty: float
    authority: float
    freshness: float
    causal_distance: float
    risk_significance: float
```

Score for decision utility, then enforce token budget.

For code agents, include symbol/dependency distance. For research, include source authority/freshness. For troubleshooting, include temporal alignment to the incident.

## 11. Memory contract

Memory write API:

```python
@dataclass
class MemoryItem:
    key: str
    value: dict
    provenance: list[str]
    scope: str
    confidence: float
    expires_at: int | None
    verified: bool
```

Reject writes when:

```text
verified == false for durable semantic memory
contains secrets
scope missing
provenance missing
```

Prefer executable regression memory to narrative memory when a failure can be encoded as a test.

## 12. Verification contract

Verification must answer the outcome question.

Example bad verifier:

```text
HTTP POST returned 200
```

Example good verifier:

```text
POST returned operation_id 123
AND independent GET shows desired state
AND user-visible health metric meets threshold
```

Represent verifier output explicitly:

```yaml
passed: false
evidence_ids: [E-11, E-12]
unresolved:
  - "service registration still DEGRADED"
severity: high
```

## 13. Runtime loop

```python
while not terminal(state):
    enforce_budget_and_deadline(state)
    update_requirements_if_needed(state)
    refresh_critical_observations(state)
    update_hypotheses(state)

    action = planner.choose_next_action(state)
    if action is None:
        break

    reject_identical_no_information_retry(state, action)
    result = execute_policy_gated_action(state, action)
    evidence = normalize_result_to_evidence(result)
    update_state(state, evidence)

    if candidate_solution_ready(state):
        verification = verifier.verify(state)
        if verification.passed:
            adversarial = adversary.challenge(state)
            if adversarial.passed:
                state.status = VERIFIED
                break
        classify_failure_and_change_strategy(state)
```

## 14. Budget enforcement

Budgets are hard runtime limits.

```yaml
budget:
  model_calls: 12
  tool_calls: 30
  wall_clock_ms: 120000
  cost_usd: 2.00
  same_strategy_failures: 2
  max_subagents: 4
```

A model cannot self-raise a budget.

## 15. Completion contract

The runtime may emit only:

```text
VERIFIED
PARTIALLY_VERIFIED
UNVERIFIED
BLOCKED
```

`VERIFIED` requires evidence. A polished answer without evidence is `UNVERIFIED`.
