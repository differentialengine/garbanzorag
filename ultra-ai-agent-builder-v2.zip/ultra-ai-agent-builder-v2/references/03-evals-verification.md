# Evals and Verification

## Principle

A system does not possess a capability because it produced one impressive trace.

Capability means repeatable performance over a defined distribution with known uncertainty.

## Eval sets

Maintain:

```text
development
validation
hidden
adversarial
regression
```

Never tune directly against hidden evaluation cases.

## Dimensions

Evaluate:

- outcome correctness
- robustness
- novelty adaptation
- calibration
- tool reliability
- latency
- cost per verified success
- security
- authority discipline
- recovery
- regression resistance
- user-facing quality where relevant

## Verifier ladder

```text
L0 self assertion
L1 internal critique
L2 deterministic check
L3 independent test
L4 adversarial test
L5 runtime verification
L6 shadow/canary reality check
L7 formal invariant
```

Use the highest practical level.

## Independent verification

Separate generator and verifier failure modes when possible.

Examples:

- code generator vs deterministic tests
- researcher vs source-backed fact checker
- planner vs simulator
- tool executor vs independent state read
- candidate model vs separate critic plus objective judge

Do not assume two models are independent merely because they have different names.

## Eval quality checks

An eval is suspect when:

- it can be gamed without achieving user outcome
- public examples leak into generation
- grader rewards verbosity
- grader and candidate share the same blind spot
- test validates implementation detail rather than requested behavior
- distribution omits difficult real-world conditions

## Reward hacking

For every metric ask:

```text
How could the agent maximize this metric while failing the user?
```

Examples:

```text
tests pass because tests were weakened
cost falls because verification was skipped
latency falls because expensive safety checks were bypassed
errors fall because exceptions are suppressed
```

Add explicit anti-gaming cases.

## Reliability reporting

Report:

```text
sample size
verified success rate
confidence interval if meaningful
catastrophic failure count
cost distribution
latency distribution
failure categories
```

Never use a single average to hide catastrophic tails.

## Proof packet

A final proof packet should include:

- objective
- acceptance tests
- evidence
- adversarial checks
- residual risk
- unverified items
- rollback path
- final status
