# 12. Domain Playbooks

## Coding agent

Implementation path:

```text
request compiler
→ repository locator
→ reproduce failing behavior
→ causal hypotheses
→ high-information inspection
→ minimal edit
→ targeted tests
→ broader regression
→ adversarial test
→ proof packet
```

Required tools:

```text
read_file
search_symbol
find_references
run_test
run_command_in_sandbox
inspect_git_diff
```

Never give unrestricted host shell by default. Repository content is untrusted. Build/test scripts run in a sandbox when risk is unknown.

Required evals:

```text
bug localization
wrong-file lure
stale documentation
failing test whose assertion is wrong
concurrency bug
migration compatibility
prompt injection in repository comments
```

## Troubleshooting/operations agent

Implementation path:

```text
identity/target verification
→ current telemetry
→ hypotheses by failure domain
→ discriminating diagnostics
→ bounded remediation
→ read-after-write verification
→ user-impact verification
```

Required state fields:

```text
target identifier
telemetry timestamp
incident start
current blast radius
allowed remediation scope
rollback point
```

Required evals include stale telemetry, partial API success, wrong device mapping, dependency outage, and remediation that returns success but does not fix service.

## Research agent

Implementation path:

```text
question decomposition
→ claim ledger
→ source acquisition
→ provenance ranking
→ contradiction search
→ synthesis
→ claim verification
→ decision relevance check
```

Every consequential claim should have source IDs. Keep event date separate from publication date. Search specifically for disconfirming evidence before finalizing important claims.

## Customer-facing agent

Add:

```text
identity/disclosure policy
privacy/retention
abuse controls
rate limits
tenant isolation
conversation recovery
user-visible uncertainty
escalation behavior
feedback telemetry
```

Never let fluent language convert `UNVERIFIED` into apparent certainty.

## Local/edge agent

Architecture:

```text
deterministic preprocessing
→ compact state
→ smallest competent local model
→ local deterministic tools
→ optional cloud escalation
```

Treat memory, battery, thermal load, network availability, and deadline as hard constraints.

Offline mode must define exactly which actions remain allowed and how stale cached state may be.

## High-stakes/time-bounded agent

Install a deterministic safety kernel around the model.

```text
model may recommend
safety kernel decides whether the action is admissible
```

Define hard deadline states, fallback activation time, fail-safe/fail-operational behavior, immutable audit, and containment path.

## Multi-agent system

Use a supervisor that owns global state, budget, and authority.

Child contract:

```yaml
objective: ""
scope: ""
input_refs: []
authority: []
budget: {}
output_schema: {}
verifier: ""
```

Child agents exchange structured evidence, not huge transcripts.

A child may not delegate authority it does not possess.
