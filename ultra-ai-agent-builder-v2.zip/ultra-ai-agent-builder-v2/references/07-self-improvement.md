# Bounded Self-Improvement

## Definition

Self-improvement is a verified increase in future capability, not arbitrary self-editing.

## Improvement candidates

Safe candidates may include:

- context retrieval
- task decomposition
- model routing
- tool selection
- prompt/procedure changes
- test generation
- verifier selection
- cache policy
- uncertainty calibration
- procedural memory

Do not autonomously change:

- authority policy
- security boundaries
- approval requirements
- credential scope
- logging requirements
- evaluator requirements
- sandboxing
- irreversible-action rules

## Proposal schema

```yaml
observed_failure: ""
failure_category: ""
suspected_mechanism: ""
proposed_change: ""
expected_gain: ""
possible_regressions: []
affected_invariants: []
baseline_metrics: {}
evaluation_set: ""
acceptance_threshold: {}
rollback_trigger: {}
```

## Acceptance sequence

```text
failure evidence
→ mechanism hypothesis
→ proposed change
→ isolated eval
→ hidden eval
→ adversarial eval
→ regression eval
→ cost/latency comparison
→ invariant check
→ canary
→ monitor
```

## Promotion rule

Accept only when:

```text
target capability improves
AND critical invariants do not regress
AND catastrophic risk does not become unacceptable
AND economics remain justified
AND evaluator integrity is intact
```

## Learning hierarchy

Do not globalize one anecdote.

Promote:

```text
observation
→ candidate lesson
→ repeated evidence
→ scoped procedure
→ cross-domain evidence
→ generalized rule
```

## Recursive bottleneck loop

After every accepted improvement ask:

```text
What became the new binding constraint?
```

Self-improvement is constraint migration, not endless rewriting.
