# 15. Self-Improvement Cookbook

Self-improvement is an evidence-gated software change process.

## Example failure

```text
Agent finds correct file only 72% of the time on hidden debugging tasks.
Trace review shows lexical search dominates context selection and misses dependency-adjacent files.
```

## Improvement proposal

```yaml
id: SI-004
observed_failure: "wrong repository localization"
category: LOC
suspected_mechanism: "lexical similarity outranks dependency distance"
change: "add dependency-distance and failing-test reachability to ranker"
expected:
  hidden_success_delta: ">= +0.03"
  context_tokens_delta: "<= +10%"
possible_regressions:
  - "dynamic calls may be under-ranked"
protected_invariants:
  - "authority policy unchanged"
  - "sandbox unchanged"
  - "verification unchanged"
```

## Gate

```text
baseline hidden eval
→ implement candidate in branch/sandbox
→ development eval
→ hidden eval
→ adversarial eval
→ regression eval
→ cost/latency comparison
→ invariant diff
```

Accept only if predefined thresholds pass.

## Canary

Deploy candidate to a small controlled scope and compare:

```text
verified success
false success
cost
latency
failure distribution
```

Rollback automatically if regression trigger is hit.

## Forbidden autonomous changes

The system may not self-modify:

```text
authority
credentials
approval requirements
sandbox escape rules
logging requirements
evaluator requirements
irreversible-action policy
```

These remain externally governed.
