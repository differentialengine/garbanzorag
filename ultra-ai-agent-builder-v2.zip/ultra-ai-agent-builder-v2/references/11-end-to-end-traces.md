# 11. End-to-End Traces

These traces show how an implementation should behave. They are not prompt examples. They are control-flow examples.

## Trace A: Troubleshooting agent repairs a local fault

### Initial contract

```yaml
objective: restore service svc-17 if a safe authorized remediation exists
acceptance:
  - final health == HEALTHY
  - no action outside svc-17
  - every mutation independently verified
```

### Initial state

```yaml
uncertainty:
  requirements: 0.05
  world_state: 0.90
  causal: 0.90
  solution: 0.80
  verification: 1.00
hypotheses:
  H1: local process fault
  H2: upstream dependency fault
  H3: stale/transient symptom
```

### Step 1: choose observation

Candidate actions:

```text
read local health: high information, no side effect
read dependency health: medium information, no side effect
restart service: low information, side effect
```

Selected: `read_health(svc-17)`.

Tool result:

```json
{"healthy": false, "local_error": true, "observed_at": "..."}
```

State update:

```text
world_state uncertainty 0.90 → 0.15
H3 weakened
H1 strengthened
```

### Step 2: discriminate H1 vs H2

Selected: `read_dependency_health(svc-17)`.

Result:

```json
{"dependency_healthy": true}
```

State update:

```text
causal uncertainty 0.90 → 0.20
H2 rejected
H1 strongly supported
```

### Step 3: propose mutation

```yaml
tool: restart_service
service_id: svc-17
action_id: task-9:restart-1
required_permission: service.restart.single
```

Policy checks:

```text
service in scope: PASS
permission present: PASS
operation allowlisted: PASS
idempotency key present: PASS
```

Tool returns:

```json
{"status": "SUCCEEDED", "operation_id": "task-9:restart-1"}
```

The runtime does **not** mark success.

### Step 4: independent effect verification

Selected: `read_health(svc-17)`.

Result:

```json
{"healthy": true, "local_error": false}
```

Verifier:

```yaml
passed: true
evidence_ids: [E-1, E-2, E-4]
```

Adversarial check confirms:

```text
no wrong-target action
no skipped verifier
no duplicate restart
```

Final:

```text
VERIFIED
```

The proof packet includes the original unhealthy observation, dependency observation, mutation operation ID, and post-action healthy observation.

---

## Trace B: Mutation timeout with unknown outcome

The agent calls `rotate_key()` and the connection times out.

Wrong behavior:

```text
retry rotate_key immediately
```

Correct behavior:

```text
ToolStatus = TIMED_OUT
mutation outcome = UNKNOWN
```

Next action is an independent state read:

```text
read_current_key_version()
```

Case 1: new version is active.

```text
mutation already occurred
→ do not retry
→ verify dependent systems
```

Case 2: old version is active.

```text
mutation did not occur
→ retry only if operation is idempotent and retry policy permits
→ reuse same operation ID
```

Case 3: state cannot be read.

```text
BLOCKED
```

This prevents duplicate or inconsistent mutations.

---

## Trace C: Coding agent refuses the first plausible cause

User: "Fix intermittent duplicate invoice creation."

Initial hypotheses:

```text
H1 retry handler lacks idempotency
H2 queue delivers duplicate messages
H3 transaction boundary commits before dedupe write
```

Instead of editing H1 immediately, the agent asks what observation separates the hypotheses.

It inspects:

```text
message IDs in duplicate invoices
transaction logs
dedupe-table writes
retry traces
```

Observation:

```text
same message ID appears twice
first transaction committed invoice
but dedupe write rolled back
```

H3 becomes dominant.

Minimal causal repair:

```text
move dedupe marker and invoice insert into same transaction
```

Verification:

```text
reproduce original fault with injected failure
run concurrency test with duplicate delivery
assert one invoice only
run regression suite
```

The agent records the injected-failure case in regression memory.

---

## Trace D: Research agent detects evaluator/source conflict

Claim: "Vendor X supports feature Y in current production release."

Search result snippet says yes.
Primary release documentation says no.

Correct state:

```yaml
claim_status: disputed
evaluator_uncertainty: 0.6
```

Next action:

```text
inspect authoritative release notes and current API/schema
```

Do not average conflicting sources into a fake 50/50 confidence.

If primary evidence shows feature absent:

```text
claim = false for current release
```

The stale secondary source becomes contradicting evidence, not support.

---

## Trace E: High-stakes deadline forces deterministic fallback

State:

```yaml
deadline_remaining_ms: 420
fallback_activation_ms: 300
```

The agent is still gathering evidence at 305 ms.

At 300 ms:

```text
stop exploratory model calls
activate prevalidated deterministic fallback policy
```

The fallback is already tested for the bounded operating envelope.

Correctness includes meeting the deadline. A theoretically better answer at 600 ms is a failure.
