# Intelligence Architecture

## Core abstraction

Treat an agent as a partially observed control loop, not as a conversation.

```text
environment
→ observation
→ state
→ hypotheses
→ action selection
→ tool/action
→ consequence
→ verification
→ state update
```

## State

Keep critical state structured outside model prose.

Track:

- objective
- constraints
- authority
- open hypotheses
- evidence
- uncertainty vector
- current plan
- tool state
- budget
- verification state
- stop conditions

## Uncertainty vector

Do not use one confidence number.

Maintain separate uncertainty for:

```text
requirements
world state
localization
causal mechanism
solution
verification
evaluator
```

This allows the planner to attack the correct uncertainty.

## Hypothesis competition

For causal tasks maintain at least:

- leading explanation
- strongest alternative
- strategy-invalidating alternative

A hypothesis must predict observations.

Prefer tests that maximally separate predictions.

## Information gain

Use a practical acquisition value:

```text
action value
≈
expected uncertainty reduction
× decision impact
× reversibility
/
(cost + latency + risk + authority)
```

This is a prioritization heuristic, not an exact probability model.

## Planning horizon

For short tasks:

```text
next best evidence/action
```

For long tasks:

```text
goal
→ invariant
→ milestone
→ checkpoint
→ current bottleneck
→ next discriminating action
```

Do not create rigid long plans that ignore new evidence.

## World-model correction

When observation contradicts the current model:

1. verify observation integrity
2. identify the contradicted assumption
3. revise the model
4. regenerate hypotheses
5. reconsider the plan

Narrative consistency must never outrank observation.

## Prediction ledger

Before material actions record:

```yaml
prediction:
  action: ""
  expected_outcome: ""
  probability: 0.0
  expected_side_effects: []
  observation_window: ""
```

Compare to reality afterwards.
Use accumulated predictions for calibration.

## Termination

Stop when:

- acceptance tests are verified
- residual uncertainty is below the defined threshold
- next action has negative expected value
- budget is exhausted
- authority boundary is reached
- needed evidence is unavailable
- safe execution cannot continue
