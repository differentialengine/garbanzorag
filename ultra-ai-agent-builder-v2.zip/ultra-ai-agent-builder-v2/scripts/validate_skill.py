#!/usr/bin/env python3
"""Validate core Agent Skills-format constraints for this package."""

from pathlib import Path
import argparse
import re
import sys

REQUIRED_DIR_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

def fail(msg, failures):
    failures.append(msg)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("skill_dir", nargs="?", default=str(Path(__file__).resolve().parent.parent))
    args = parser.parse_args()
    root = Path(args.skill_dir).resolve()
    skill = root / "SKILL.md"
    failures = []

    if not skill.exists():
        print("VALIDATION FAILED\n- missing SKILL.md")
        raise SystemExit(1)

    text = skill.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        fail("SKILL.md must start with YAML frontmatter", failures)
    parts = text.split("---", 2)
    if len(parts) < 3:
        fail("frontmatter is not closed", failures)
        front = ""
    else:
        front = parts[1]

    def field(name):
        m = re.search(rf"^{re.escape(name)}:\s*(.+)$", front, re.M)
        return m.group(1).strip().strip('"') if m else None

    name = field("name")
    desc = field("description")

    if not name:
        fail("missing name", failures)
    else:
        if len(name) > 64:
            fail("name exceeds 64 characters", failures)
        if not REQUIRED_DIR_RE.fullmatch(name):
            fail("name must be lowercase kebab-case", failures)
        if name != root.name:
            fail(f"name '{name}' must match parent directory '{root.name}'", failures)

    if not desc:
        fail("missing description", failures)
    elif len(desc) > 1024:
        fail("description exceeds 1024 characters", failures)

    for rel in [
        "references/00-build-contract.md",
        "references/01-intelligence-architecture.md",
        "references/03-evals-verification.md",
        "references/04-safety-authority.md",
        "references/07-self-improvement.md",
        "assets/agent-spec.yaml",
        "assets/task-state.yaml",
        "assets/eval-suite.yaml",
        "assets/authority-policy.yaml",
        "assets/proof-packet.yaml",
    ]:
        if not (root / rel).exists():
            fail(f"missing referenced resource: {rel}", failures)

    if failures:
        print("VALIDATION FAILED")
        for x in failures:
            print(f"- {x}")
        sys.exit(1)

    print("SKILL FORMAT VALIDATED")
    print(f"name={name}")
    print(f"description_chars={len(desc)}")
    print(f"skill_lines={len(text.splitlines())}")

if __name__ == "__main__":
    main()
