#!/usr/bin/env python3
"""Scaffold a production-agent repository from this skill."""
from pathlib import Path
import argparse
import shutil

FILES = {
    "AGENT_SPEC.yaml": "assets/agent-spec.yaml",
    "AGENTS.md": "assets/AGENTS.harness.md",
    "policies/authority.yaml": "assets/authority-policy.yaml",
    "policies/tool-policy.yaml": "assets/tool-policy.yaml",
    "evals/eval-plan.yaml": "assets/eval-suite.yaml",
    "proof-packet.yaml": "assets/proof-packet.yaml",
    "production-readiness.md": "assets/production-readiness.md",
    "runbook.md": "assets/runbook.md",
}

DEFAULT_TEXT = {
    "architecture.md": """# Architecture\n\nDocument the outcome contract, capability vector, failure topology, state schema, component graph, tool boundaries, authority, verification path, deployment stages, and rollback.\n""",
    "observability.md": """# Observability\n\nDefine structured events, verified-success metrics, cost per verified success, p95 latency, retry/escalation, failure taxonomy, calibration, authority denials, alerts, and trace reconstruction.\n""",
}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("destination")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--with-reference-runtime", action="store_true")
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parent.parent
    dest = Path(args.destination).resolve()
    (dest / "evals" / "regression").mkdir(parents=True, exist_ok=True)
    (dest / "policies").mkdir(parents=True, exist_ok=True)

    for target, source in FILES.items():
        src = skill_root / source
        out = dest / target
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.exists() and not args.force:
            print(f"skip: {out}")
            continue
        shutil.copy2(src, out)
        print(f"created: {out}")

    for target, content in DEFAULT_TEXT.items():
        out = dest / target
        if out.exists() and not args.force:
            print(f"skip: {out}")
            continue
        out.write_text(content, encoding="utf-8")
        print(f"created: {out}")

    if args.with_reference_runtime:
        src = skill_root / "examples" / "reference_agent"
        out = dest / "reference_agent"
        if out.exists() and args.force:
            shutil.rmtree(out)
        if not out.exists():
            shutil.copytree(src, out)
            print(f"created: {out}")

if __name__ == "__main__":
    main()
