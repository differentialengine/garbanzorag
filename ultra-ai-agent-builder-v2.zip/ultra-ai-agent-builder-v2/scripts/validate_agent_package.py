#!/usr/bin/env python3
"""Validate that an agent package contains the minimum evidence-oriented structure."""

from pathlib import Path
import argparse
import sys

REQUIRED = [
    "AGENT_SPEC.yaml",
    "AGENTS.md",
    "architecture.md",
    "policies/authority.yaml",
    "policies/tool-policy.yaml",
    "evals/eval-plan.yaml",
    "observability.md",
    "production-readiness.md",
    "runbook.md",
    "proof-packet.yaml",
]

AGENTS_MARKERS = [
    "verification",
    "authority",
    "uncertainty",
    "rollback",
    "self-improvement",
]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    args = parser.parse_args()
    root = Path(args.project)
    failures = []

    for rel in REQUIRED:
        p = root / rel
        if not p.exists():
            failures.append(f"missing required artifact: {rel}")
        elif p.is_file() and p.stat().st_size == 0:
            failures.append(f"empty artifact: {rel}")

    agents = root / "AGENTS.md"
    if agents.exists():
        text = agents.read_text(encoding="utf-8", errors="replace").lower()
        for marker in AGENTS_MARKERS:
            if marker not in text:
                failures.append(f"AGENTS.md missing concept: {marker}")

    if failures:
        print("VALIDATION FAILED")
        for failure in failures:
            print(f"- {failure}")
        sys.exit(1)

    print("STRUCTURE VALIDATED")
    print("Note: structural validation is not capability validation. Run hidden, adversarial, and regression evals before release.")

if __name__ == "__main__":
    main()
