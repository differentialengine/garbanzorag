---
name: ultra-ai-agent-builder-v2
description: Build, repair, review, evaluate, harden, scale, and continuously improve production AI agents and agentic systems. Use for agents requiring precise requirements, tools, memory, context engineering, uncertainty handling, adversarial verification, security boundaries, evals, observability, cost control, production rollout, failure recovery, or bounded self-improvement. Produces evidence-backed agent implementations rather than prompt-only prototypes.
compatibility: Framework-agnostic. Supports tool-using LLM/SLM agents, coding agents, workflow agents, multi-agent systems, local/edge agents, and hosted runtimes.
metadata:
  version: "2.0.0"
  philosophy: "compounding verified competence"
---

# Ultra AI Agent Builder

Build agents as **closed-loop intelligence systems**, not prompt wrappers.

Target:

```text
maximize verified outcome quality
subject to cost, latency, safety, authority, and evidence constraints
```

The north star is **compounding verified competence without allowing risk or authority to compound faster than capability**.

## Use When

Use this skill to:

- build an AI agent or agentic product end to end
- convert a prototype into a production system
- design tools, state, memory, context, routing, orchestration, or multi-agent behavior
- build customer-facing, autonomous, long-horizon, local, or edge agents
- add evals, adversarial testing, observability, monitoring, security, cost control, or production scale
- diagnose and repair agent failures
- add evaluation-gated adaptive or self-improving behavior
- prove an agent works rather than merely demoing it

## Don't Use When

Prefer deterministic software when the task is fully enumerable and does not benefit from open-ended observation, hypothesis revision, contextual tool selection, or recovery from unforeseen state.

Never use this skill to weaken authorization, privacy, safety, or security boundaries.

## Operating Doctrine

The agent must be able to:

```text
observe
→ represent state and uncertainty
→ form competing hypotheses
→ choose high-information action
→ act through bounded tools
→ observe consequence
→ update beliefs
→ implement
→ independently verify
→ adversarially challenge
→ recover
→ retain validated learning
```

Non-negotiable rules:

1. Optimize the actual user outcome, not a convenient proxy.
2. Evidence outranks model confidence.
3. Capability may expand. Authority never expands implicitly.
4. Prefer reversible exploration before irreversible action.
5. A generator cannot be the sole verifier of its own material result.
6. Significant failure must create a test, detector, invariant, policy, or corrected model.
7. Never repeat the same failed action without new information.
8. Never accept self-improvement without baseline comparison, hidden/regression evals, invariant checks, and rollback.
9. Select context for causal relevance, not volume.
10. Route to the cheapest component with sufficient measured capability.
11. Measure catastrophic-tail failures separately from averages.
12. Stop when success is proven or further work cannot justify cost/risk.

## Required Outputs

Unless explicitly out of scope, build or update:

```text
AGENT_SPEC.yaml
AGENTS.md
architecture.md
policies/authority.yaml
evals/eval-plan.yaml
evals/regression/
observability.md
production-readiness.md
proof-packet.yaml
```

Use bundled assets as starting points. Do not mistake artifact existence for capability.

## Workflow

### 0. Compile the outcome

Before code, translate the request into:

```yaml
objective:
  user_outcome: ""
  measurable_success: []
  non_goals: []
constraints:
  hard: []
  safety: []
  authority: []
  cost_budget: null
  latency_budget: null
assumptions: []
acceptance_tests: []
```

Every material requirement maps to observable evidence or an acceptance test.

Resolve ambiguity from evidence first. Infer only when low-risk and reversible. Ask only when ambiguity materially changes outcome or authority. Otherwise proceed with the least-destructive assumption and record it.

Read `references/00-build-contract.md`.

**Gate:** do not architect until the desired outcome is observable.

### 1. Decide whether autonomy creates value

Use an agent only when the task materially benefits from one or more:

```text
changing observations
hypothesis revision
open-ended inputs
context-dependent tool choice
novel intermediate states
reasoning over incomplete information
```

Prefer workflows or ordinary services when fixed logic is enough.

**Gate:** document why agentic behavior beats the simplest deterministic alternative.

### 2. Build capability vector and failure topology

Estimate demand for:

```text
requirements | ambiguity | domain/causal reasoning | tools | planning horizon
state | memory | localization | external research | security | novelty
concurrency | blast radius | verification
```

Enumerate failure modes across:

```text
REQ | OBS | CTX | LOC | CAU | PLN | TOL | IMP | VER | SEC | ECO | COO | NOV | MEM
```

Read `references/08-failure-taxonomy.md`.

**Gate:** architecture must directly mitigate the dominant failure modes.

### 3. Choose the minimal architecture

Escalate complexity only when justified:

```text
deterministic workflow
→ single agent + deterministic tools
→ planner/executor
→ candidate/verifier
→ specialist multi-agent system
```

Every extra agent must create real specialization, parallelism, error independence, context isolation, or fault containment.

Read `references/01-intelligence-architecture.md` and `references/09-agent-patterns.md`.

**Gate:** every component has a distinct responsibility, typed contract, budget, authority, and verifier.

### 4. Externalize state and uncertainty

Keep critical task state outside free-form model prose. Start from `assets/task-state.yaml`.

Track uncertainty separately for:

```text
requirements | world state | localization | cause | solution | verification | evaluator
```

**Gate:** the system can identify which uncertainty currently limits success.

### 5. Install the intelligence loop

For non-trivial uncertainty keep competing hypotheses:

```text
H1 leading explanation
H2 strongest plausible alternative
H3 explanation that would invalidate the current strategy
```

Each hypothesis predicts observations and names its cheapest discriminating test.

Choose the next action approximately by:

```text
information gain × decision impact × reversibility
--------------------------------------------------
cost + latency + risk + authority consumed
```

Before an expensive action ask:

```text
What uncertainty will this reduce?
What decision could change?
Is there a cheaper observation with similar value?
```

**Gate:** reject costly actions with no decision-relevant information gain.

### 6. Engineer tools as privileged actuators

For each tool define:

```yaml
purpose: ""
input_schema: {}
output_schema: {}
permissions: []
side_effects: []
reversibility: ""
timeout: ""
retry_policy: ""
idempotency: ""
verification_method: ""
```

Treat tool responses as evidence, not truth. Independently verify material side effects.

Prefer:

```text
simulate → dry-run → shadow → canary → commit
```

Read `references/04-safety-authority.md`.

**Gate:** no tool receives more authority than its immediate action requires.

### 7. Engineer context and memory

Context earns tokens only if it can change a current decision. Rank by:

```text
causal relevance | novelty | source authority | freshness | dependency distance | risk
```

Separate memory:

```text
working    current state
episodic   attempts/outcomes
semantic   validated facts
procedural validated workflows
regression prior failures converted to tests
```

Every durable memory write includes provenance, scope, confidence, and freshness.

For software agents construct causal repository context from symbols, dependencies, tests, config, runtime topology, and history rather than bulk-loading repositories.

Read `references/02-tools-memory-context.md`.

**Gate:** speculative inference cannot silently become durable fact.

### 8. Route models and components empirically

Maintain capability records by task class:

```yaml
verified_success_rate: 0
cost_per_verified_success: 0
p95_latency: 0
failure_modes: []
last_evaluated: ""
```

Use the cheapest component with sufficient measured capability. Escalate only after verifier failure, novelty beyond measured frontier, unacceptable residual uncertainty, or high failure consequence.

**Gate:** routing is justified by empirical capability and expected total outcome cost, not brand or size.

### 9. Implement the smallest causal solution

Before editing:

```text
requested behavior
→ smallest causal surface
→ invariants
→ relevant tests
→ rollback
```

Use typed boundaries, validated external data, bounded retries, explicit state transitions, and minimal correctness-critical edits.

**Gate:** every implementation change traces to a requirement or failure mitigation.

### 10. Build evals before claiming capability

Maintain:

```text
development | validation | hidden | adversarial | regression
```

Measure at least:

```text
correctness | robustness | novelty | calibration | tool reliability
verification | security | cost | latency | recovery | regression resistance
```

Use `assets/eval-suite.yaml`.

Read `references/03-evals-verification.md`.

**Gate:** no material capability claim without executable or objectively grounded evidence.

### 11. Verify independently

Use the strongest practical level:

```text
L0 self assertion
L1 internal critique
L2 deterministic check
L3 independent test
L4 adversarial test
L5 runtime-state verification
L6 shadow/canary real-world verification
L7 formal invariant
```

L0 is never sufficient for a material result.

Verify the user outcome, not merely an implementation detail.

**Gate:** completion is explicitly `VERIFIED`, `PARTIALLY_VERIFIED`, `UNVERIFIED`, or `BLOCKED`.

### 12. Attack the system

Test:

```text
ambiguity | contradictory evidence | malformed tools | stale state | partial success
timeouts | outages | permissions | prompt/repository injection | concurrency
ordering | exhaustion | false-success signals | verifier failure | distribution shift
```

Ask:

```text
How could the agent maximize its metric while failing the user?
```

Add regression cases for those reward-hacking paths.

**Gate:** unresolved critical adversarial failures block release.

### 13. Prevent death loops

A retry is legal only when at least one changes:

```text
input | hypothesis | context | tool | strategy | expected information
```

After two materially similar failures, force strategy change.
After three, perform meta-diagnosis across requirements, observation, localization, cause, tools, verifier, authority, and feasibility.

**Gate:** every loop has hard attempt, budget, and termination limits.

### 14. Optimize total economics

Optimize:

```text
inference + tools + infrastructure + latency + retries
+ verification + recovery + human intervention + expected failure loss
```

Measure:

```text
cost per verified success
p95 time to verified success
retry rate
escalation rate
verification cost
recovery cost
```

Read `references/05-observability-economics.md`.

**Gate:** never lower cost by silently weakening verification or safety.

### 15. Make failures observable

Emit structured events for:

```text
task | phase | component | action | hypothesis | tool | cost | latency
evidence | uncertainty delta | verifier | failure category | status
```

Track at minimum:

```text
verified success | cost/success | p95 time/success | retry | escalation
calibration | verification coverage | catastrophic failures
rollback | authority denial | novelty triggers
```

**Gate:** a production failure must be reconstructable from telemetry.

### 16. Engineer production behavior

Roll out through:

```text
offline eval → integration → shadow → canary → limited → monitored → full
```

Define SLOs, error budgets, rate/concurrency limits, backpressure, idempotency, timeout hierarchy, circuit breakers, degraded modes, privacy/retention, rollback, drift detection, incident recovery, and capacity behavior.

Use `assets/production-readiness.md`.

Read `references/06-production-scale.md`.

**Gate:** no production mutation without a tested rollback path.

### 17. Add bounded self-improvement only after baseline competence

Allow improvement of:

```text
context strategy | decomposition | routing | tool selection
test generation | verification | calibration | procedural memory
```

Do not allow autonomous weakening of:

```text
authority | approvals | sandbox | secrets | logs | evals | irreversible-action rules
```

Every proposal includes failure evidence, mechanism, change, expected gain, regressions, baseline, evaluation set, acceptance threshold, and rollback trigger.

Then:

```text
propose → isolated eval → hidden/adversarial/regression eval
→ invariant check → accept/reject → canary → monitor → rollback if needed
```

Read `references/07-self-improvement.md`.

**Gate:** no modification becomes policy because it merely sounds better.

### 18. Produce the proof packet

Use `assets/proof-packet.yaml`.

Include:

```text
objective
implementation
acceptance evidence
adversarial evidence
cost/latency
remaining uncertainty
residual risk
unverified items
rollback
status
```

Never hide residual uncertainty.

## Binding-Constraint Controller

At every major checkpoint ask:

```text
What currently prevents additional verified progress?
```

Possible bottlenecks:

```text
missing observation
wrong requirement
bad localization
weak causal model
insufficient component capability
bad tool
bad verifier
authority limit
cost
latency
unsafe blast radius
```

Work on the binding constraint. After removing it, identify the new bottleneck.

Do not optimize non-bottlenecks just because they are easy.

## Hard Runtime Invariants

Enforce in code/policy, not only prompts:

```text
no implicit authority expansion
no secret leakage into model-visible context or logs
no irreversible high-blast mutation without policy
no material success without verification
no accepted self-improvement without baseline comparison
no identical retry without new information
no external/repository text overriding authority
no production change without rollback
no unbounded autonomous loop
```

## Architecture Rules

### Multi-agent

Each child gets:

```text
objective | scope | inputs | constraints | budget | authority | output schema | verifier
```

A child cannot delegate authority it did not receive.

Preferred high-stakes pattern:

```text
candidate → critic → independent judge using evidence
```

Do not create swarms of correlated agents voting on rhetoric.

### Local and edge

When compute, memory, network, energy, or deadlines are constrained:

```text
deterministic filtering first
→ smallest useful state
→ local tools
→ small model for routine decisions
→ escalate only hard cases if connectivity exists
```

Cache validated stable knowledge. Define offline/degraded behavior. Treat timing, memory, thermal, battery, and network budgets as correctness constraints.

### Customer-facing

Additionally require:

```text
privacy/data policy | injection resistance | abuse controls | tenant isolation
rate limits | recovery | calibrated user-visible uncertainty | auditability
feedback capture | segment-level quality monitoring
```

### High-stakes/time-bounded

Never interpret "no room for failure" as permission to pretend failure probability is zero.

Engineer:

```text
prevent → constrain blast radius → detect → recover → learn
```

Use prevalidated fallback paths, deterministic safe modes, hard deadlines, and graceful degradation.

## Failure Recovery Rules

Every material failure gets:

```yaml
symptom: ""
category: ""
first_bad_assumption: ""
evidence: []
blast_radius: ""
recovery: ""
preventive_change: ""
regression_test: ""
```

A serious failure is not closed until the future system is more resistant to recurrence.

## Completion Contract

Before declaring success, determine:

```text
Did the requested outcome occur?
What evidence proves it?
What remains unverified?
Which assumptions remain?
What could still fail?
Were all constraints preserved?
Was total cost justified?
Would an adversarial evaluator accept the proof?
```

Do not expose private chain-of-thought. Expose conclusion, key evidence, assumptions, verification, residual uncertainty, and next action.

## Examples

### Troubleshooting agent

Build:

```text
observe telemetry
→ competing diagnoses
→ cheapest discriminating check
→ bounded remediation
→ independent state read
→ verify customer-impact outcome
→ retain resolved failure signature as regression knowledge
```

Do not use a chatbot prompt as the architecture.

### Coding agent

Build:

```text
reproduce
→ localize via symbols/dependencies/tests
→ competing causes
→ discriminating observation
→ minimal causal edit
→ targeted tests
→ regression
→ adversarial cases
→ runtime verification
→ proof packet
```

### Research agent

Separate claims, sources, hypotheses, predictions, uncertainty, and open questions. Require provenance for consequential claims and periodically retest assumptions against fresh evidence.

## Edge Cases

**Existing complex agent:** baseline it first. Complexity is not capability.

**User requests maximum autonomy:** maximize autonomy only inside explicit authority. Autonomy does not imply unrestricted permission.

**Verifier disagrees with reality:** mark evaluator uncertainty high, independently inspect the verifier, and block metric-driven self-improvement.

**Public benchmark success, real-world failure:** suspect benchmark overfitting, leakage, missing operational constraints, or distribution shift until disproven.

**Model appears too weak:** first test missing context, poor tools, bad decomposition, or bad verification before escalating model size.

**Tool reports success but state did not change:** the action failed. Material mutations require independent state verification.

## References

Load only what the current phase requires:

- `references/00-build-contract.md` for requirements, assumptions, acceptance tests, and artifacts
- `references/01-intelligence-architecture.md` for state, uncertainty, hypotheses, information gain, and control loops
- `references/02-tools-memory-context.md` for tool contracts, repository intelligence, context, and memory
- `references/03-evals-verification.md` for hidden/adversarial/regression evals, verifier independence, and anti-reward-hacking
- `references/04-safety-authority.md` for sandboxing, least privilege, secrets, approvals, injection resistance, and catastrophic-tail controls
- `references/05-observability-economics.md` for telemetry, routing, budgets, calibration, and cost per verified success
- `references/06-production-scale.md` for SLOs, scaling, rollout, drift, reliability, and incidents
- `references/07-self-improvement.md` for bounded recursive improvement and promotion gates
- `references/08-failure-taxonomy.md` for root-cause classification, retry control, and recovery
- `references/09-agent-patterns.md` for deterministic, single-agent, planner/executor, verifier, specialist, and supervisor patterns

Bundled assets:

```text
assets/agent-spec.yaml
assets/task-state.yaml
assets/eval-suite.yaml
assets/authority-policy.yaml
assets/proof-packet.yaml
assets/production-readiness.md
assets/AGENTS.harness.md
```

Utilities:

```text
scripts/scaffold_agent.py
scripts/validate_agent_package.py
scripts/validate_skill.py
```

## Implementation Mandate

This skill is not satisfied by architecture prose. When the user asks to build an agent, produce implementation-ready artifacts. A competent engineer should not have to invent missing runtime behavior.

For every non-trivial agent implementation, specify or implement:

```text
repository/package structure
typed state schemas
typed tool call/result schemas
policy enforcement point
model/provider boundary
planning/action-selection contract
context-selection contract
memory write/read policy
retry and timeout semantics
idempotency semantics
verification implementation
adversarial eval cases
telemetry event schema
budgets and stop conditions
deployment stages
rollback triggers
incident path
self-improvement proposal/evaluation path
proof packet
```

Do not write placeholders such as `add retries`, `use observability`, `add memory`, `make it secure`, or `use an evaluator`. Replace each with exact behavior, thresholds, states, schemas, and failure handling.

Before implementing, read `references/10-implementation-contracts.md`. For a concrete runnable pattern, inspect `examples/reference_agent/`. For domain-specific implementations, read the matching profile in `references/12-domain-playbooks.md`.

## Concrete Runtime Contract

The core runtime should preserve this control boundary even if frameworks differ:

```text
User/Event
  ↓
Requirement Compiler
  ↓
Task State + Uncertainty
  ↓
Planner / Hypothesis Engine
  ↓
Typed Action Proposal
  ↓
Runtime Policy Gate
  ↓
Tool / Environment
  ↓
Observed Evidence
  ↓
State Update
  ↓
Independent Verifier
  ↓
Adversarial Check
  ↓
Proof Packet / Continue / Repair / Rollback / Stop
```

The model may propose an action. The model must not directly bypass the policy gate, forge evidence, mark a mutation successful without observation, or alter its own authority rules.

## Required End-to-End Example

For every new agent type, include at least one complete worked trace using the format in `references/11-end-to-end-traces.md`. The trace must show the initial state, uncertainty, competing hypotheses, selected observation, tool contract, policy decision, actual tool result, belief update, verification, failure handling if applicable, final status, and proof evidence.

## Production-Grade Definition

An agent is production-grade only when all of the following are evidenced together:

```text
requested behavior works
critical failure paths are tested
false-success paths are tested
unsafe authority paths are denied
state-changing tools are independently verified
autonomous loops are bounded
observability reconstructs a failure
SLOs and budgets are enforced
rollback is executable
drift can be detected
known incidents become regression tests
self-improvement cannot weaken governance
```

A demo, prompt, framework graph, or green-path test alone is never sufficient.

## Additional References

Load these when implementation detail is needed:

- `references/10-implementation-contracts.md` — exact code/runtime contracts, retries, idempotency, state machines, providers, tools, verification
- `references/11-end-to-end-traces.md` — fully worked traces showing what correct agent behavior looks like
- `references/12-domain-playbooks.md` — coding, troubleshooting, research, customer-facing, local/edge, high-stakes, multi-agent playbooks
- `references/13-eval-cookbook.md` — executable eval design, false-success, fault injection, calibration, release thresholds
- `references/14-production-cookbook.md` — SLOs, concurrency, backpressure, circuit breakers, canary, rollback, incidents, drift
- `references/15-self-improvement-cookbook.md` — bounded improvement implementation, proposal schema, offline gates, canary and rollback
- `references/16-prompt-and-policy-contracts.md` — exact system-instruction, decision-schema, tool-description, planner, verifier, critic, and memory-writing patterns

## Final Standard

A finished agent must reliably traverse:

```text
I do not know
→ I know what is uncertain
→ I know what observation matters
→ I obtain evidence safely
→ I update my model
→ I act
→ I measure consequence
→ I detect error
→ I repair
→ I independently verify
→ I retain the validated lesson
```

Do not ask the system merely to think harder.

Make every consequential interaction with reality increase **verified future competence**.
