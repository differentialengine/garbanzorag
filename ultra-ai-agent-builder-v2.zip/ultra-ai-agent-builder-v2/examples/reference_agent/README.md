# Runnable Reference Agent

This example is deliberately small and dependency-free so the control architecture is visible.

It demonstrates a troubleshooting agent that diagnoses an unhealthy service and may restart it only when the evidence supports a local fault and the runtime policy grants that authority.

It includes structured state, competing hypotheses, information-gain ordering, runtime authorization, idempotent mutation, independent post-mutation verification, bounded loops, telemetry, and adversarial tests.

Run:

```bash
python -m unittest discover -s tests -v
python run_demo.py
```

The planner here is deterministic. In a production LLM agent, replace the planner with a model-backed planner that emits the same typed action objects. Preserve the policy, tool, state, and verifier boundaries.
