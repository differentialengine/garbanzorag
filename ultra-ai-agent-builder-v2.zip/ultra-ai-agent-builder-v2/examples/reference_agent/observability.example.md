# Reference Observability

Every tool attempt emits:

```json
{
  "event": "tool_call",
  "task_id": "t1",
  "tool": "restart_service",
  "action_id": "t1:restart"
}
```

Policy denials emit the tool and reason. Runtime phase events include step number.

A production version should additionally emit latency, model/provider, token count, cost, state version, evidence IDs, uncertainty deltas, retry reason, failure category, and verifier result.

Do not log hidden chain-of-thought. Log structured decisions, action intents, policy outcomes, evidence references, and verification results.
