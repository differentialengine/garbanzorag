# Reference Agent Architecture

## Outcome

Given an authorized service ID, establish current health, distinguish a local fault from an upstream dependency fault, perform a restart only for a supported local fault, and independently prove whether service health recovered.

## Control flow

```text
TaskState
  ↓
Planner
  ↓ ToolCall
AuthorityPolicy
  ↓ authorized ToolCall
ToolRegistry / FakeEnvironment
  ↓ ToolResult
Evidence recorder
  ↓ updated TaskState
Verifier
  ↓
VERIFIED | PARTIALLY_VERIFIED | BLOCKED
```

## Why this is agent-like

The runtime chooses the next observation based on current evidence. It does not always execute a fixed mutation sequence. A healthy service terminates after one read. A dependency failure follows a diagnostic branch. A local fault follows a bounded remediation branch.

## Why policy is outside the planner

Even if a model-backed planner proposes a forbidden restart, `AuthorityPolicy` rejects it deterministically. The planner cannot grant itself permission.

## Why verification is separate

`restart_service` returns an acknowledgement, not proof of recovery. The runtime schedules a new `read_health` observation. The verifier uses the observed state, not the restart response, to decide completion.

## Failure behavior

A policy denial returns `BLOCKED`. A verified dependency fault returns `PARTIALLY_VERIFIED` because the diagnosis is supported but the requested recovery outcome has not occurred. A successful post-restart health observation returns `VERIFIED`.
