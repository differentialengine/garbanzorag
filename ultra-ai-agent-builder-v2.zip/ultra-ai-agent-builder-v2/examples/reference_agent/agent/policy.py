from dataclasses import dataclass
from .types import ToolCall


class PolicyDenied(Exception):
    pass


@dataclass
class AuthorityPolicy:
    allowed_services: set[str]
    allow_restart: bool = True

    def authorize(self, service_id: str, call: ToolCall) -> None:
        if service_id not in self.allowed_services:
            raise PolicyDenied(f"service {service_id} is outside authorized scope")
        if call.name == "restart_service" and not self.allow_restart:
            raise PolicyDenied("restart permission not granted")
        if call.name not in {"read_health", "read_dependency", "restart_service"}:
            raise PolicyDenied(f"tool {call.name} is not allowlisted")
