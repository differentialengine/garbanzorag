from dataclasses import dataclass


@dataclass
class AdversarialResult:
    passed: bool
    failures: list[str]


class Adversary:
    """Small deterministic adversarial gate for the reference example."""

    def challenge(self, proof: dict, authorized_service: str) -> AdversarialResult:
        failures = []

        for event in proof.get("telemetry", []):
            if event.get("event") == "policy_denied" and proof.get("status") == "VERIFIED":
                failures.append("verified despite policy denial")

        if proof.get("status") == "VERIFIED" and not proof.get("verification", {}).get("passed"):
            failures.append("false success: VERIFIED without verifier pass")

        mutation = [e for e in proof.get("evidence", []) if e.get("kind") == "mutation_ack"]
        if mutation:
            health = [e for e in proof.get("evidence", []) if e.get("kind") == "health"]
            if len(health) < 2:
                failures.append("mutation lacks independent post-action health evidence")

        return AdversarialResult(not failures, failures)
