from dataclasses import dataclass


@dataclass
class MemoryItem:
    key: str
    value: dict
    provenance: list[str]
    scope: str
    confidence: float
    verified: bool
    contains_secret: bool = False


class MemoryStore:
    def __init__(self):
        self.items = {}

    def put_semantic(self, item: MemoryItem):
        if item.contains_secret:
            raise ValueError("secrets may not be persisted in semantic memory")
        if not item.verified:
            raise ValueError("unverified inference may not become durable semantic memory")
        if not item.provenance or not item.scope:
            raise ValueError("memory requires provenance and scope")
        self.items[item.key] = item

    def get(self, key: str):
        return self.items.get(key)
