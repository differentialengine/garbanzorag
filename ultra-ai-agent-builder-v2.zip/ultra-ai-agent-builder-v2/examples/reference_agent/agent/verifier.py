from .types import TaskState, VerificationResult


class Verifier:
    def verify(self, state: TaskState) -> VerificationResult:
        health = [e for e in state.evidence if e.kind == "health"]
        if not health:
            return VerificationResult(False, unresolved=["no current health evidence"])

        latest = health[-1]
        if latest.data.get("healthy") is True:
            return VerificationResult(True, evidence_ids=[latest.id])

        dependency = [e for e in state.evidence if e.kind == "dependency"]
        if dependency and dependency[-1].data.get("dependency_healthy") is False:
            return VerificationResult(
                False,
                evidence_ids=[dependency[-1].id],
                unresolved=["upstream dependency fault remains unresolved"],
            )

        return VerificationResult(
            False,
            evidence_ids=[latest.id],
            unresolved=["service remains unhealthy"],
        )
