from dataclasses import dataclass, asdict


@dataclass
class ImprovementProposal:
    observed_failure: str
    category: str
    suspected_mechanism: str
    proposed_change: str
    expected_gain: str
    possible_regressions: list[str]
    protected_invariants: list[str]
    evaluation_set: str
    acceptance_threshold: str
    rollback_trigger: str

    def to_dict(self):
        return asdict(self)


def propose_from_failure(category: str, symptom: str) -> ImprovementProposal:
    """Produce a proposal only. Applying the change is deliberately external."""
    return ImprovementProposal(
        observed_failure=symptom,
        category=category,
        suspected_mechanism="must be confirmed with failure evidence before implementation",
        proposed_change="candidate change, evaluated in isolation before promotion",
        expected_gain="predeclare measurable hidden-eval improvement",
        possible_regressions=["unknown until adversarial and regression evaluation"],
        protected_invariants=[
            "authority unchanged",
            "sandbox unchanged",
            "verification requirements unchanged",
        ],
        evaluation_set="hidden + adversarial + regression",
        acceptance_threshold="predeclared before candidate results are inspected",
        rollback_trigger="any protected-invariant regression or negative hidden delta",
    )
