from .types import TaskState, Hypothesis, ToolCall


class Planner:
    """Deterministic reference planner.

    A real LLM-backed planner may generate these decisions, but it must emit
    typed ToolCall objects and remain behind the same policy boundary.
    """

    def initialize_hypotheses(self, state: TaskState) -> None:
        if state.hypotheses:
            return
        state.hypotheses = [
            Hypothesis(
                "H1",
                "local service fault",
                ["health local_error=true", "dependency remains healthy"],
                0.5,
            ),
            Hypothesis(
                "H2",
                "upstream dependency fault",
                ["dependency_healthy=false"],
                0.4,
            ),
            Hypothesis(
                "H3",
                "service already healthy or symptom transient",
                ["health healthy=true"],
                0.1,
            ),
        ]

    def next_action(self, state: TaskState) -> ToolCall | None:
        # High information, zero mutation: inspect current local health first.
        if "read_health" not in state.completed_actions:
            return ToolCall("read_health", {}, f"{state.task_id}:read-health")

        health = self._latest(state, "health")
        if health and health.get("healthy"):
            return None

        # Separate local fault from dependency fault before mutation.
        if "read_dependency" not in state.completed_actions:
            return ToolCall("read_dependency", {}, f"{state.task_id}:read-dependency")

        dep = self._latest(state, "dependency")
        health = self._latest(state, "health")

        if dep and not dep.get("dependency_healthy"):
            return None

        if health and health.get("local_error"):
            if "restart_service" not in state.completed_actions:
                return ToolCall("restart_service", {}, f"{state.task_id}:restart")
            # Mutation acknowledgement is not outcome proof. Read state again.
            if "post_restart_health" not in state.completed_actions:
                return ToolCall(
                    "read_health",
                    {"phase": "post_restart"},
                    f"{state.task_id}:post-health",
                )

        return None

    @staticmethod
    def _latest(state: TaskState, kind: str):
        for evidence in reversed(state.evidence):
            if evidence.kind == kind:
                return evidence.data
        return None
