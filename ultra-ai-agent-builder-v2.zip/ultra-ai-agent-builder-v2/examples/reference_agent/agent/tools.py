from dataclasses import dataclass, field
from typing import Dict
from .types import ToolCall, ToolResult, ToolStatus


@dataclass
class FakeEnvironment:
    service_modes: Dict[str, str]
    dependency_healthy: Dict[str, bool]
    processed_operations: set[str] = field(default_factory=set)

    def read_health(self, service_id: str) -> ToolResult:
        mode = self.service_modes[service_id]
        return ToolResult(
            ToolStatus.SUCCEEDED,
            {
                "service_id": service_id,
                "healthy": mode == "healthy",
                "local_error": mode == "local_fault",
            },
        )

    def read_dependency(self, service_id: str) -> ToolResult:
        return ToolResult(
            ToolStatus.SUCCEEDED,
            {"service_id": service_id, "dependency_healthy": self.dependency_healthy[service_id]},
        )

    def restart_service(self, service_id: str, operation_id: str) -> ToolResult:
        if operation_id in self.processed_operations:
            return ToolResult(
                ToolStatus.SUCCEEDED,
                {"operation_id": operation_id, "replayed": True},
            )

        self.processed_operations.add(operation_id)

        if self.service_modes[service_id] == "local_fault":
            self.service_modes[service_id] = "healthy"

        return ToolResult(ToolStatus.SUCCEEDED, {"operation_id": operation_id})


class ToolRegistry:
    def __init__(self, env: FakeEnvironment):
        self.env = env

    def execute(self, service_id: str, call: ToolCall) -> ToolResult:
        if call.name == "read_health":
            return self.env.read_health(service_id)
        if call.name == "read_dependency":
            return self.env.read_dependency(service_id)
        if call.name == "restart_service":
            return self.env.restart_service(service_id, call.action_id)
        return ToolResult(ToolStatus.FAILED, message=f"unknown tool {call.name}")
