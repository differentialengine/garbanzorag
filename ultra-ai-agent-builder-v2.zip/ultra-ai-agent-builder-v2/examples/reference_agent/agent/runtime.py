from dataclasses import asdict
import hashlib
import json

from .types import Evidence, Status, TaskState, ToolStatus
from .policy import PolicyDenied


class AgentRuntime:
    def __init__(self, planner, tools, policy, verifier, telemetry, max_steps: int = 8):
        self.planner = planner
        self.tools = tools
        self.policy = policy
        self.verifier = verifier
        self.telemetry = telemetry
        self.max_steps = max_steps
        self._evidence_counter = 0

    def run(self, state: TaskState) -> dict:
        self.planner.initialize_hypotheses(state)

        for step in range(self.max_steps):
            self.telemetry.emit("phase", task_id=state.task_id, phase="PLAN", step=step)

            if state.tool_calls_remaining <= 0:
                state.status = Status.BLOCKED
                state.stop_reason = "tool-call budget exhausted"
                break

            call = self.planner.next_action(state)
            if call is None:
                verification = self.verifier.verify(state)
                state.status = (
                    Status.VERIFIED if verification.passed
                    else Status.PARTIALLY_VERIFIED
                )
                state.stop_reason = "verification completed"
                break

            signature = self._strategy_signature(call, state)
            if signature in state.retry_signatures:
                state.status = Status.BLOCKED
                state.stop_reason = f"repeated action without new information: {call.name}"
                break
            state.retry_signatures.append(signature)

            try:
                self.policy.authorize(state.service_id, call)
            except PolicyDenied as exc:
                self.telemetry.emit(
                    "policy_denied",
                    task_id=state.task_id,
                    tool=call.name,
                    reason=str(exc),
                )
                state.status = Status.BLOCKED
                state.stop_reason = str(exc)
                break

            state.tool_calls_remaining -= 1
            self.telemetry.emit(
                "tool_call",
                task_id=state.task_id,
                tool=call.name,
                action_id=call.action_id,
            )

            result = self.tools.execute(state.service_id, call)
            if result.status != ToolStatus.SUCCEEDED:
                state.status = Status.BLOCKED
                state.stop_reason = f"tool failure: {result.status.value}"
                break

            self._record_result(state, call, result.data)

            # Acknowledgement after mutation is intentionally not success.
            if call.name == "restart_service":
                state.uncertainty["verification"] = 1.0

        else:
            state.status = Status.BLOCKED
            state.stop_reason = "max-step bound reached"

        verification = self.verifier.verify(state)
        if verification.passed:
            state.status = Status.VERIFIED

        return {
            "objective": f"restore or diagnose service {state.service_id}",
            "status": state.status.value,
            "stop_reason": state.stop_reason,
            "verification": asdict(verification),
            "evidence": [asdict(e) for e in state.evidence],
            "telemetry": self.telemetry.events,
        }

    def _record_result(self, state, call, data):
        self._evidence_counter += 1

        if call.name == "read_health":
            kind = "health"
            action = (
                "post_restart_health"
                if call.arguments.get("phase") == "post_restart"
                else "read_health"
            )
            state.uncertainty["world_state"] = 0.1
        elif call.name == "read_dependency":
            kind = "dependency"
            action = "read_dependency"
            state.uncertainty["causal"] = 0.2
        else:
            kind = "mutation_ack"
            action = call.name

        state.evidence.append(
            Evidence(
                id=f"E-{self._evidence_counter}",
                kind=kind,
                data=data,
                source=call.name,
            )
        )
        state.completed_actions.append(action)
        state.version += 1

    @staticmethod
    def _strategy_signature(call, state):
        # State version changes only when new evidence arrives. The signature
        # therefore rejects a truly identical no-information loop.
        raw = json.dumps(
            {
                "name": call.name,
                "arguments": call.arguments,
                "state_version": state.version,
            },
            sort_keys=True,
        )
        return hashlib.sha256(raw.encode()).hexdigest()
