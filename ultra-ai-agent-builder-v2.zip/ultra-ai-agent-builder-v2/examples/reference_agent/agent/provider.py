from dataclasses import dataclass
from typing import Protocol, Any


@dataclass
class ModelRequest:
    task_class: str
    instructions: str
    context_refs: list[str]
    output_schema: dict[str, Any]
    max_tokens: int = 1024
    deadline_ms: int | None = None


@dataclass
class ModelResponse:
    structured_output: dict[str, Any]
    input_tokens: int
    output_tokens: int
    latency_ms: int
    provider: str
    model: str


class ModelProvider(Protocol):
    def generate(self, request: ModelRequest) -> ModelResponse:
        ...
