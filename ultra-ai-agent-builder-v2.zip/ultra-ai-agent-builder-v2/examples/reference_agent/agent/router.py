from dataclasses import dataclass


@dataclass
class CapabilityRecord:
    component: str
    task_class: str
    verified_success_rate: float
    cost_per_verified_success: float
    p95_latency_ms: int
    catastrophic_failures: int = 0


class EmpiricalRouter:
    """Choose the cheapest component meeting explicit measured thresholds."""

    def __init__(self, records: list[CapabilityRecord]):
        self.records = records

    def choose(self, task_class: str, min_success: float, max_latency_ms: int):
        candidates = [
            r for r in self.records
            if r.task_class == task_class
            and r.verified_success_rate >= min_success
            and r.p95_latency_ms <= max_latency_ms
            and r.catastrophic_failures == 0
        ]
        if not candidates:
            return None
        return min(candidates, key=lambda r: r.cost_per_verified_success)
