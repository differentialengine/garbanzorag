from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Status(str, Enum):
    VERIFIED = "VERIFIED"
    PARTIALLY_VERIFIED = "PARTIALLY_VERIFIED"
    UNVERIFIED = "UNVERIFIED"
    BLOCKED = "BLOCKED"


class ToolStatus(str, Enum):
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"
    PARTIAL = "PARTIAL"
    UNKNOWN = "UNKNOWN"
    TIMED_OUT = "TIMED_OUT"
    DENIED = "DENIED"


@dataclass
class Evidence:
    id: str
    kind: str
    data: Dict[str, Any]
    source: str


@dataclass
class Hypothesis:
    id: str
    claim: str
    predictions: List[str]
    score: float
    status: str = "open"


@dataclass
class ToolCall:
    name: str
    arguments: Dict[str, Any]
    action_id: str


@dataclass
class ToolResult:
    status: ToolStatus
    data: Dict[str, Any] = field(default_factory=dict)
    message: str = ""


@dataclass
class VerificationResult:
    passed: bool
    evidence_ids: List[str] = field(default_factory=list)
    unresolved: List[str] = field(default_factory=list)


@dataclass
class TaskState:
    task_id: str
    service_id: str
    version: int = 0
    uncertainty: Dict[str, float] = field(default_factory=lambda: {
        "requirements": 0.05,
        "world_state": 0.9,
        "causal": 0.9,
        "solution": 0.8,
        "verification": 1.0,
        "evaluator": 0.1,
    })
    hypotheses: List[Hypothesis] = field(default_factory=list)
    evidence: List[Evidence] = field(default_factory=list)
    completed_actions: List[str] = field(default_factory=list)
    retry_signatures: List[str] = field(default_factory=list)
    tool_calls_remaining: int = 8
    status: Status = Status.UNVERIFIED
    stop_reason: Optional[str] = None
