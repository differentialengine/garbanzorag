from pprint import pprint
from agent.types import TaskState
from agent.planner import Planner
from agent.policy import AuthorityPolicy
from agent.tools import FakeEnvironment, ToolRegistry
from agent.verifier import Verifier
from agent.telemetry import Telemetry
from agent.runtime import AgentRuntime


env = FakeEnvironment(
    service_modes={"svc-1": "local_fault"},
    dependency_healthy={"svc-1": True},
)

runtime = AgentRuntime(
    Planner(),
    ToolRegistry(env),
    AuthorityPolicy(allowed_services={"svc-1"}, allow_restart=True),
    Verifier(),
    Telemetry(),
)

proof = runtime.run(TaskState(task_id="demo-1", service_id="svc-1"))
pprint(proof)
