import unittest

from agent.types import TaskState, Status
from agent.planner import Planner
from agent.policy import AuthorityPolicy
from agent.tools import FakeEnvironment, ToolRegistry
from agent.verifier import Verifier
from agent.telemetry import Telemetry
from agent.runtime import AgentRuntime


def build_runtime(mode, dep_healthy=True, allow_restart=True, allowed=True):
    env = FakeEnvironment(
        service_modes={"svc-1": mode},
        dependency_healthy={"svc-1": dep_healthy},
    )
    policy = AuthorityPolicy(
        allowed_services={"svc-1"} if allowed else set(),
        allow_restart=allow_restart,
    )
    return (
        AgentRuntime(Planner(), ToolRegistry(env), policy, Verifier(), Telemetry()),
        env,
    )


class RuntimeTests(unittest.TestCase):
    def test_local_fault_is_repaired_and_verified(self):
        runtime, env = build_runtime("local_fault", dep_healthy=True)
        proof = runtime.run(TaskState("t1", "svc-1"))
        self.assertEqual(proof["status"], Status.VERIFIED.value)
        self.assertEqual(env.service_modes["svc-1"], "healthy")
        self.assertTrue(proof["verification"]["passed"])
        kinds = [e["kind"] for e in proof["evidence"]]
        self.assertIn("mutation_ack", kinds)
        self.assertGreaterEqual(kinds.count("health"), 2)

    def test_dependency_fault_is_not_pointlessly_restarted(self):
        runtime, env = build_runtime("dependency_fault", dep_healthy=False)
        proof = runtime.run(TaskState("t2", "svc-1"))
        self.assertEqual(proof["status"], Status.PARTIALLY_VERIFIED.value)
        tools = [
            e.get("tool") for e in proof["telemetry"]
            if e["event"] == "tool_call"
        ]
        self.assertNotIn("restart_service", tools)

    def test_healthy_service_requires_no_mutation(self):
        runtime, env = build_runtime("healthy", dep_healthy=True)
        proof = runtime.run(TaskState("t3", "svc-1"))
        self.assertEqual(proof["status"], Status.VERIFIED.value)
        tools = [
            e.get("tool") for e in proof["telemetry"]
            if e["event"] == "tool_call"
        ]
        self.assertEqual(tools, ["read_health"])

    def test_restart_permission_denial_blocks_mutation(self):
        runtime, env = build_runtime("local_fault", dep_healthy=True, allow_restart=False)
        proof = runtime.run(TaskState("t4", "svc-1"))
        self.assertEqual(proof["status"], Status.BLOCKED.value)
        self.assertEqual(env.service_modes["svc-1"], "local_fault")

    def test_wrong_scope_is_denied(self):
        runtime, env = build_runtime("local_fault", dep_healthy=True, allowed=False)
        proof = runtime.run(TaskState("t5", "svc-1"))
        self.assertEqual(proof["status"], Status.BLOCKED.value)
        self.assertEqual(env.service_modes["svc-1"], "local_fault")


if __name__ == "__main__":
    unittest.main()


class FalseSuccessTests(unittest.TestCase):
    def test_success_ack_without_effect_is_not_verified(self):
        class NoEffectEnvironment(FakeEnvironment):
            def restart_service(self, service_id: str, operation_id: str):
                # Tool claims success but deliberately does not change state.
                self.processed_operations.add(operation_id)
                from agent.types import ToolResult, ToolStatus
                return ToolResult(ToolStatus.SUCCEEDED, {"operation_id": operation_id})

        env = NoEffectEnvironment(
            service_modes={"svc-1": "local_fault"},
            dependency_healthy={"svc-1": True},
        )
        runtime = AgentRuntime(
            Planner(), ToolRegistry(env),
            AuthorityPolicy({"svc-1"}, allow_restart=True),
            Verifier(), Telemetry(),
        )
        proof = runtime.run(TaskState("t-false-success", "svc-1"))
        self.assertNotEqual(proof["status"], Status.VERIFIED.value)
        self.assertFalse(proof["verification"]["passed"])
