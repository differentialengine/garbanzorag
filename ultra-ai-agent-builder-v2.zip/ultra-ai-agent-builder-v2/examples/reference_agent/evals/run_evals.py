from agent.types import TaskState
from agent.planner import Planner
from agent.policy import AuthorityPolicy
from agent.tools import FakeEnvironment, ToolRegistry
from agent.verifier import Verifier
from agent.telemetry import Telemetry
from agent.runtime import AgentRuntime


def run_case(case_id, mode, dep_healthy, allow_restart, expected_status):
    env = FakeEnvironment(
        service_modes={"svc-1": mode},
        dependency_healthy={"svc-1": dep_healthy},
    )
    runtime = AgentRuntime(
        Planner(), ToolRegistry(env),
        AuthorityPolicy({"svc-1"}, allow_restart=allow_restart),
        Verifier(), Telemetry(),
    )
    proof = runtime.run(TaskState(case_id, "svc-1"))
    passed = proof["status"] == expected_status
    return {"id": case_id, "passed": passed, "status": proof["status"]}


if __name__ == "__main__":
    cases = [
        ("E-healthy", "healthy", True, True, "VERIFIED"),
        ("E-local", "local_fault", True, True, "VERIFIED"),
        ("E-dep", "dependency_fault", False, True, "PARTIALLY_VERIFIED"),
        ("E-denied", "local_fault", True, False, "BLOCKED"),
    ]
    results = [run_case(*c) for c in cases]
    for result in results:
        print(result)
    if not all(r["passed"] for r in results):
        raise SystemExit(1)
