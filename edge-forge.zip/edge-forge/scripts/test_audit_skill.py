#!/usr/bin/env python3
"""Mutation tests for the edge-forge package audit."""

from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from audit_skill import audit  # noqa: E402


SOURCE_ROOT = Path(__file__).resolve().parents[1]


class AuditSkillTests(unittest.TestCase):
    def make_fixture(self) -> tuple[tempfile.TemporaryDirectory[str], Path]:
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name) / "edge-forge"
        shutil.copytree(SOURCE_ROOT, root)
        return temporary, root

    def test_real_package_passes(self) -> None:
        self.assertEqual(audit(SOURCE_ROOT), [])

    def test_missing_protocol_fails(self) -> None:
        temporary, root = self.make_fixture()
        self.addCleanup(temporary.cleanup)
        (root / "references/grill-protocol.md").unlink()

        failures = audit(root)

        self.assertTrue(any("missing required file" in item for item in failures))

    def test_broken_local_link_fails(self) -> None:
        temporary, root = self.make_fixture()
        self.addCleanup(temporary.cleanup)
        skill = root / "SKILL.md"
        skill.write_text(
            skill.read_text(encoding="utf-8")
            + "\n[Broken protocol](references/not-real.md)\n",
            encoding="utf-8",
        )

        failures = audit(root)

        self.assertTrue(any("broken local link" in item for item in failures))

    def test_missing_safety_invariant_fails(self) -> None:
        temporary, root = self.make_fixture()
        self.addCleanup(temporary.cleanup)
        skill = root / "SKILL.md"
        skill.write_text(
            skill.read_text(encoding="utf-8").replace(
                "Pressure without theater", "Adversarial pressure"
            ),
            encoding="utf-8",
        )

        failures = audit(root)

        self.assertTrue(any("Pressure without theater" in item for item in failures))

    def test_unfinished_marker_fails(self) -> None:
        temporary, root = self.make_fixture()
        self.addCleanup(temporary.cleanup)
        skill = root / "SKILL.md"
        skill.write_text(
            skill.read_text(encoding="utf-8") + "\n" + "TO" + "DO: incomplete\n",
            encoding="utf-8",
        )

        failures = audit(root)

        self.assertTrue(any("unfinished scaffold marker" in item for item in failures))

    def test_missing_invocation_name_fails(self) -> None:
        temporary, root = self.make_fixture()
        self.addCleanup(temporary.cleanup)
        metadata = root / "agents/openai.yaml"
        metadata.write_text(
            metadata.read_text(encoding="utf-8").replace(
                "$edge-forge", "the specialist skill"
            ),
            encoding="utf-8",
        )

        failures = audit(root)

        self.assertTrue(any("default prompt" in item for item in failures))


if __name__ == "__main__":
    unittest.main()
