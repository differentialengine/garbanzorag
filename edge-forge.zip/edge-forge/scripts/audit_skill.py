#!/usr/bin/env python3
"""Audit structural and behavioral invariants of the edge-forge skill."""

from __future__ import annotations

import re
import sys
from pathlib import Path


REQUIRED_FILES = (
    "SKILL.md",
    "agents/openai.yaml",
    "references/edge-selection.md",
    "references/grill-protocol.md",
    "references/forge-protocol.md",
    "references/monetization.md",
    "references/artifact-schemas.md",
    "references/smoke-tests.md",
)

REQUIRED_SKILL_PHRASES = (
    "decision territory",
    "Do not promise",
    "one question at a time",
    "world-class",
    "monetizable",
    "Browse when",
    "authorization",
    "Pressure without theater",
)

REFERENCE_REQUIREMENTS = {
    "references/edge-selection.md": (
        "Apply hard gates",
        "Verify the market now",
        "bounded test",
    ),
    "references/grill-protocol.md": (
        "Ask exactly one question per turn",
        "Stop conditions",
        "Crucible",
    ),
    "references/forge-protocol.md": (
        "Proof ladder",
        "counterfactual twins",
        "compounding artifact",
    ),
    "references/monetization.md": (
        "weakest link governs",
        "Run commitment tests",
        "must not send",
    ),
    "references/artifact-schemas.md": (
        "Edge thesis",
        "Experiment contract",
        "Evolution review",
    ),
    "references/smoke-tests.md": (
        "## Discover",
        "## Grill",
        "## Monetize",
        "### Accept when",
        "### Reject when",
    ),
}

MARKERS = (
    "TO" + "DO",
    "TB" + "D",
    "Replace this " + "placeholder",
    "[TO" + "DO:",
)
LINK_PATTERN = re.compile(r"\[[^\]]+\]\(([^)]+)\)")


def audit(root: Path) -> list[str]:
    failures: list[str] = []

    for relative in REQUIRED_FILES:
        if not (root / relative).is_file():
            failures.append(f"missing required file: {relative}")

    if failures:
        return failures

    skill_text = (root / "SKILL.md").read_text(encoding="utf-8")
    for phrase in REQUIRED_SKILL_PHRASES:
        if phrase.casefold() not in skill_text.casefold():
            failures.append(f"SKILL.md missing required phrase: {phrase}")

    ui_text = (root / "agents/openai.yaml").read_text(encoding="utf-8")
    if "$edge-forge" not in ui_text:
        failures.append("agents/openai.yaml default prompt must name $edge-forge")

    for relative, phrases in REFERENCE_REQUIREMENTS.items():
        text = (root / relative).read_text(encoding="utf-8")
        for phrase in phrases:
            if phrase.casefold() not in text.casefold():
                failures.append(f"{relative} missing required phrase: {phrase}")

    inspectable = tuple(root.rglob("*.md")) + tuple(root.rglob("*.yaml"))
    for path in inspectable:
        text = path.read_text(encoding="utf-8")
        for marker in MARKERS:
            if marker in text:
                failures.append(f"unfinished scaffold marker in {path.relative_to(root)}: {marker}")

        for target in LINK_PATTERN.findall(text):
            if target.startswith(("http://", "https://", "#")):
                continue
            target_path = (path.parent / target.split("#", 1)[0]).resolve()
            if not target_path.exists():
                failures.append(
                    f"broken local link in {path.relative_to(root)}: {target}"
                )

    return failures


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: audit_skill.py PATH_TO_EDGE_FORGE", file=sys.stderr)
        return 2

    root = Path(sys.argv[1]).resolve()
    failures = audit(root)
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}", file=sys.stderr)
        return 1

    print("edge-forge audit passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
