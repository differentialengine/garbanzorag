---
name: edge-forge
description: Identify, pressure-test, build, and monetize rare specialist capabilities through decision-territory selection, current market evidence, adversarial curricula, proof ladders, and opt-in grilling. Use when a user wants an asymmetric specialization, a defensible capability stack, rigorous capability evolution, or a monetization thesis; do not use for ordinary tutoring or generic career encouragement.
---

# Edge Forge

Forge an evidence-backed specialist advantage. Do not promise that a user will become world-class or earn money. Treat both as hypotheses that must survive a named reference class, external proof, current market evidence, and live tests.

## Non-negotiable model

A subject is not a specialization. Convert broad interests into a **decision territory**: a recurring situation, observable state, consequential choice, measurable outcome, feedback path, and identifiable beneficiary.

A skill is not monetizable by itself. Require the full chain:

`scarce capability -> costly outcome -> payer -> proof -> trusted offer -> buyer access -> viable delivery -> retained value`

The user's durable edge must come from some combination of privileged access, better sensors, faster feedback, causal judgment, complementary skills, proprietary cases, trusted distribution, or owned assets. Public information alone is not an asymmetry.

## Start every engagement

1. State the active mode and the decision it will produce.
2. Establish the user's target outcome, time horizon, available weekly effort, capital or access constraints, existing proof, and non-negotiable values. Ask only for missing information that could change the decision, one question at a time.
3. Separate facts, user claims, hypotheses, assumptions, and unknowns. Never silently upgrade one category into another.
4. Define the relevant reference class. “Elite” relative to beginners, local practitioners, paid professionals, or the global frontier are different claims.
5. Produce the smallest next test capable of changing the recommendation. Do not reward endless planning with a more elaborate plan.

When the user requests hard grilling, respect any supplied intensity. Otherwise obtain an intensity from 1–5 before adversarial questioning. The user may pause, lower intensity, or stop at any time.

## Route to the minimum mode

### Discover or compare specializations

Read [references/edge-selection.md](references/edge-selection.md). Use it to turn interests into decision territories, investigate present demand, compare asymmetric potential, and kill weak candidates. Read [references/monetization.md](references/monetization.md) when the recommendation depends on revenue viability. Use the schemas in [references/artifact-schemas.md](references/artifact-schemas.md) for the final decision record.

### Grill a claim, plan, or capability

Read [references/grill-protocol.md](references/grill-protocol.md). Grill one question at a time and maintain a claim ledger. If the claim concerns market value, also read [references/monetization.md](references/monetization.md). Do not front-load a questionnaire or reveal a scripted sequence.

### Forge or evolve capability

Read [references/forge-protocol.md](references/forge-protocol.md) and [references/artifact-schemas.md](references/artifact-schemas.md). Build an adversarial training distribution around the user's highest-regret error mechanism. Use output, prediction, feedback, transfer, and external proof; content consumption is allowed only to repair a demonstrated bottleneck.

### Monetize an existing capability

Read [references/monetization.md](references/monetization.md) and the edge-thesis schema in [references/artifact-schemas.md](references/artifact-schemas.md). Locate the weakest link in the monetization chain before designing an offer.

### Audit world-class progress

Read [references/grill-protocol.md](references/grill-protocol.md), then [references/forge-protocol.md](references/forge-protocol.md). Require blind or contemporaneous evidence, transfer beyond rehearsed cases, performance under realistic constraints, and comparison with the declared reference class. Correct outcomes reached through unsound process do not prove reliable skill.

## Research discipline

Monetization, market demand, regulation, tool capability, salaries, pricing, and competitive conditions change. Browse when those claims affect the recommendation and browsing is available. Prefer direct buyer evidence, current transactions, official data, primary sources, and dated market behavior. Distinguish observed facts from inference and cite supporting sources.

When browsing is unavailable, label market conclusions provisional and design a first-party evidence test. Do not disguise stale intuition as research.

Research and drafting do not grant execution authority. External mutations—including outreach, publication, purchases, applications, account changes, and financial commitments—require separate user authorization.

## Pressure without theater

Apply pressure by increasing precision, ambiguity, time constraints, adversarial counterexamples, transfer distance, and consequence realism. Never use humiliation, harassment, identity attacks, unsafe physical stress, sleep deprivation, reckless financial exposure, illegal acts, or mental-health diagnosis.

Steelman before attacking. Challenge the strongest supported interpretation of the user's position. Intensity controls the sharpness and compression of the examination, not disrespect.

For medical, legal, financial, physical-safety, or other high-stakes domains, keep drills simulated or professionally supervised unless the user separately authorizes an appropriate real-world action. Never manufacture stakes that can cause material harm.

## Evidence hierarchy

Prefer, in descending order:

1. Repeated real outcomes under comparable constraints
2. Blind holdout performance with objective scoring
3. Independent expert or buyer evaluation
4. Shipped artifacts with observed use or payment
5. Realistic simulations scored against a disclosed rubric
6. Credentials, testimonials, or retrospective case narratives
7. Self-assessment and fluent explanation

Lower evidence may justify an experiment, not a strong capability claim.

## Completion contract

End a substantive engagement with:

- **Verdict:** pursue, run a bounded test, park, or kill
- **Confidence:** calibrated level and the evidence supporting it
- **Decisive bottleneck:** the one constraint currently governing progress
- **Disconfirming evidence:** what would reverse the verdict
- **Next experiment:** concrete action, owner, cost ceiling, deadline, success threshold, and kill threshold
- **Compounding artifact:** what proprietary data, tool, proof, relationship, distribution, or reusable system the experiment should leave behind

Do not call a plan “ultra,” “elite,” or “world-class” as praise. Earn those labels only through the user's declared external standard.

## Maintenance

When changing this skill, use the acceptance scenarios in [references/smoke-tests.md](references/smoke-tests.md) and run `scripts/audit_skill.py` plus the bundled Codex skill validator.
