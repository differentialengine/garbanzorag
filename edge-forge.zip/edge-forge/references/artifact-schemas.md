# Artifact Schemas

Use only the artifacts required by the active mode. Preserve unknowns instead of filling them with plausible language.

## Edge thesis

```markdown
# Edge Thesis

Decision territory:
Beneficiary:
Economic buyer:
Costly recurring situation:
Decision or execution advantage:
Observable outcome and horizon:
Reference class:

Existing asymmetry:
Asymmetry to manufacture:
Feedback source and latency:
Proof standard:
Buyer-access path:
Compounding residue:

Strongest evidence:
Critical assumptions:
Fatal unknown:
Disconfirming evidence:
Current verdict and confidence:
```

## Candidate matrix

For each dimension record `strong`, `uncertain`, or `weak`, followed by evidence and confidence. Never calculate a total when a hard gate fails.

| Candidate | Value | Learning position | Asymmetry | Durability | Fit | Fatal gate | Verdict |
|---|---|---|---|---|---|---|---|

After the table, name the strongest rejected candidate and the decisive reason it lost.

## Capability graph node

```markdown
Capability:
Function: sensing / representation / judgment / execution / correction / communication / capture
Observable behavior:
Prerequisites:
Failure mechanisms:
Feedback source:
Proof standard:
Current evidence:
Confidence:
Downstream capabilities affected:
```

## Claim ledger

| Claim | Status | Best evidence | Confidence | Dependencies | Reversal evidence |
|---|---|---|---|---|---|

Allowed statuses: `supported`, `plausible`, `unknown`, `contradicted`, `evasive`.

## Proof ladder

| Level | Required performance | Constraints | Evidence source | Consistency requirement | Status |
|---|---|---|---|---|---|
| 0 Vocabulary | | | | | |
| 1 Reconstruction | | | | | |
| 2 Variation | | | | | |
| 3 Holdout | | | | | |
| 4 Consequence | | | | | |
| 5 Transfer | | | | | |
| 6 Leverage | | | | | |

## Experiment contract

```markdown
Decision this experiment will change:
Hypothesis:
Strongest competing hypothesis:
Precommitted prediction and confidence:
Intervention or case:
Objective measure:
Owner:
Authorization boundary:
Cost ceiling:
Deadline:
Success threshold:
Kill threshold:
Ambiguous-result rule:
Expected compounding residue:
```

## Evidence ledger

| Date | Case | Decision-time information | Decision | Confidence | Outcome | Process quality | Residual mechanism | Policy update | Transfer result |
|---|---|---|---|---|---|---|---|---|---|

Do not rewrite predictions after seeing results.

## Evolution review

```markdown
Verdict: pursue / bounded test / park / kill
Evidence added this cycle:
Highest-regret residual:
Recurring error mechanism:
Confidence calibration change:
Decision compiled into a tool or procedure:
Sensor, access, territory, or capture change required:
Next adversarial case:
Next transfer test:
Next market commitment test:
Asset retained:
Disconfirming trigger:
```
