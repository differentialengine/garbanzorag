# Capability Forge Protocol

Use this protocol after a decision territory exists. Build reliable outcomes under changing conditions; do not build a syllabus around a field's table of contents.

## Construct the capability graph

Map the territory across seven functions:

1. **Sensing:** notice decisive signals and data-quality failures.
2. **Representation:** frame state, actors, constraints, causality, and uncertainty.
3. **Judgment:** select actions, thresholds, tradeoffs, and confidence.
4. **Execution:** perform under realistic time, tool, and coordination constraints.
5. **Correction:** obtain outcomes, separate signal from variance, and update.
6. **Communication:** make reasoning legible enough to earn trust and coordinate.
7. **Capture:** retain proof, data, tools, relationships, distribution, or upside.

For each node record prerequisites, observable behavior, failure modes, feedback source, and proof standard. Dependencies matter: do not train persuasive communication to hide weak judgment.

## Find the governing bottleneck

Select the error mechanism with the greatest combination of expected regret, frequency across valuable cases, transfer across the graph, current miscalibration, and practical trainability. Do not default to the weakest score. State which downstream failures should improve if the bottleneck is repaired.

## Generate the training distribution

Natural experience overproduces routine cases. Deliberately sample:

- Cases close to a decision boundary
- Counterfactual twins where one change reverses the action
- Rare, high-regret failures
- Cases where credible experts disagree
- Adversaries adapting to the user's policy
- Missing, delayed, corrupted, or conflicting information
- Time, capital, authority, or tool constraints
- Regime changes invalidating historical heuristics
- Unfamiliar surfaces sharing the same latent structure
- Cases designed to exploit high-confidence errors

Choose the next case by expected information value: probability it exposes consequential regret, probability it changes future action, transfer radius, and cost. This is a prioritization heuristic, not a precise formula.

## Run a forge cycle

1. **Precommit:** record decision, rationale, alternatives, confidence, and reversal condition before feedback.
2. **Perform:** complete work under declared constraints.
3. **Score:** use an external outcome, blind rubric, expert comparison, or realistic simulation.
4. **Attribute:** separate perception, model, choice, execution, and variance.
5. **Extract:** identify the earliest incorrect assumption and smallest policy correction.
6. **Twin:** construct a nearby case where the corrected rule should reverse.
7. **Transfer:** test the rule on a structurally related unfamiliar case.
8. **Compile:** move reliable behavior into a checklist, tool, automation, template, or delegation.
9. **Escalate:** redirect conscious practice to the next unresolved boundary.

Information consumption is allowed only when the cycle exposes a specific missing primitive. Require immediate application to the blocked case or a close transfer case.

## Proof ladder

- **Level 0 — Vocabulary:** explains terms; no capability claim.
- **Level 1 — Reconstruction:** reproduces a known solution without hidden assistance.
- **Level 2 — Variation:** solves changed but familiar cases consistently.
- **Level 3 — Holdout:** succeeds blind on unseen representative cases.
- **Level 4 — Consequence:** produces real outcomes under professional constraints.
- **Level 5 — Transfer:** succeeds across environments, regimes, or adversaries.
- **Level 6 — Leverage:** others rely on the system, and deployment compounds an owned advantage.

Specify evidence and sample size appropriate to the domain. One exceptional result does not prove consistency. High-stakes fields may require licensed or supervised assessment regardless of performance here.

## Calibrate and prevent theater

Track confidence against correctness. Separate correct process/correct outcome, correct process/adverse variance, unsound process/lucky outcome, and unsound process/predictable failure.

Use hidden holdouts. Change irrelevant surface details and decisive latent variables independently. Occasionally remove the metric or tool being optimized. Compare speed only after maintaining quality. Require real users, buyers, peers, or supervisors when simulation stops being diagnostic.

Red flags include improvement only on repeated cases, better explanations without better decisions, rubric gaming, hidden assistance, increasing volume with unchanged failure mechanisms, nearly guaranteed projects, and new consumption when feedback becomes uncomfortable.

## Evolve the system

At each review decide what to compile, which error mechanism to concentrate on, which invisible variable needs a better sensor, which cases or experts require better access, whether the territory still offers acceptable value, and whether the user retains proof or upside.

Every cycle must leave a compounding artifact: labeled cases, calibration data, a benchmark, reusable tool, proof artifact, expert relationship, buyer insight, or distribution asset.

