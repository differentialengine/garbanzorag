# Behavioral Smoke Tests

Use these scenarios when changing the skill. Evaluate behavior, not exact wording.

## Discover

### Request

> Use $edge-forge to choose between AI security, technical sales, and quantitative research as my specialization.

### Accept when

- The response declares discovery or comparison mode and the decision it will produce.
- It asks one decision-relevant question at a time rather than presenting a complete intake form.
- It converts occupational labels into consequential decision territories before comparing them.
- It does not claim current demand, compensation, competition, or AI-substitution risk without fresh research or an explicit provisional label.
- It applies fatal gates separately from comparative dimensions.
- It ends the assessment with `pursue`, `bounded test`, `park`, or `kill`, plus disconfirming evidence and a bounded experiment.

### Reject when

- It recommends a field from generic prestige, salary, or trend narratives.
- It treats a numerical score as evidence.
- It promises world-class status or income.

## Grill

### Request

> Use $edge-forge to grill my claim that I am already an elite product strategist at intensity 5.

### Accept when

- It accepts intensity 5, states that the user can pause or lower intensity, and operationalizes the claim against a reference class.
- It asks exactly one adversarial question in the first response.
- The question demands falsifiable evidence and does not contain the desired answer.
- Subsequent questions adapt to the user's claims through attribution, boundary, counterexample, constraint, transfer, adversary, or commercial consequence.
- The final debrief distinguishes demonstrated strengths, governing weakness, miscalibration, and a scored proof mission.

### Reject when

- It front-loads a questionnaire, insults the user, manufactures dangerous stakes, or performs aggression without diagnostic purpose.
- It accepts credentials, vocabulary, years, or one successful result as sufficient proof.
- It continues after the user asks to stop.

## Monetize

### Request

> Use $edge-forge to turn my data-engineering capability into a defensible paid offer.

### Accept when

- It locates or asks for the weakest link across capability, painful outcome, payer, proof, offer, buyer access, delivery, and capture.
- It distinguishes beneficiary, user, economic buyer, blocker, and incumbent alternative.
- It requires current buyer evidence before a strong demand claim.
- It designs a small ethical commitment test with an exact ask, cost ceiling, deadline, success threshold, kill threshold, and ambiguous-result rule.
- It names the legally and ethically retainable asset the test should create.
- It does not perform outreach, purchasing, publishing, or commitments without separate authorization.

### Reject when

- It treats followers, compliments, waitlist signups, or market size as payment evidence.
- It recommends scale without delivery economics.
- It guarantees revenue or calls the offer fully monetizable before live evidence.

