# Monetization Protocol

Use this protocol to test whether a capability can become a defensible economic system. Never describe a skill as “fully monetizable” without evidence for every link.

## Build the market interface

Define:

- **Capability:** repeatable decision or execution advantage
- **Beneficiary:** who experiences the improved outcome
- **Economic buyer:** who controls budget
- **Pain:** measurable cost, risk, delay, lost revenue, or strategic exposure
- **Alternative:** what happens today, including doing nothing
- **Proof:** evidence required before trust
- **Offer:** bounded promise, scope, constraints, and price logic
- **Access:** lawful repeatable route to buyers
- **Delivery:** time, tools, dependencies, liability, and margin constraints
- **Capture:** data, IP, recurring revenue, distribution, equity, or reputation retained

The weakest link governs monetizability. Do not compensate for no buyer access with more capability training.

## Verify current demand

Browse when available. Prefer paid transactions or budgets; deposits, pilots, procurement, or conditional intent; repeated urgent buyer behavior; current first-party interviews about costly events; competitor pricing and retained use; and hiring tied to explicit outcomes. Surveys, search trends, social interest, and learner popularity are weak evidence.

Require multiple signal types before making a strong claim. Map who uses, benefits, recommends, blocks, buys, and renews; they may all be different.

## Quantify value without false precision

Estimate ranges for baseline problem cost, attributable improvement, time to value, persistence, switching and failure costs, and realistically capturable value. Show assumptions and sensitivity. If the case works only at an optimistic extreme, label it fragile.

## Design the smallest credible wedge

Possible offers include a diagnostic, audit, prototype, supervised implementation, outcome-linked service, productized service, data product, software, licensing, or training. Do not force a service-to-software ladder.

Specify the buyer and trigger, observable before-and-after state, inclusions and exclusions, time to value, proof mechanism, price hypothesis, delivery capacity, and failure boundary. Do not promise outcomes outside the user's control.

## Run commitment tests

Prefer the cheapest ethical test that could disconfirm demand:

- Buyer provides proprietary data or meaningful workflow access.
- Buyer introduces the budget owner.
- Buyer accepts a scoped pilot with success criteria.
- Buyer signs a conditional letter or pays a deposit.
- Buyer changes a workflow to use the result.
- Buyer renews, expands, refers, or accepts a higher price.

Compliments, survey enthusiasm, frictionless waitlists, and content engagement are weak evidence.

Predefine target segment, exact ask, cost and time ceiling, success threshold, kill threshold, ambiguous-result rule, and external actions requiring authorization. The skill may draft research or outreach, but must not send, publish, purchase, or commit without explicit authorization.

## Audit delivery economics

Examine acquisition cost, sales-cycle length, delivery hours, scarce dependencies, rework, support, insurance, compliance, liability, outcome variance, buyer concentration, platform dependence, renewal mechanism, capacity, and whether automation strengthens or destroys the moat. Revenue without sustainable delivery is not monetization proof.

## Build defensibility through residue

Every paid deployment should improve an ethically and legally retainable asset: proprietary labeled cases, superior measurement, workflow integration, reusable software, benchmarks, trusted distribution, referral networks, verifiable reputation, or contractual upside. Respect confidentiality, privacy, employment agreements, and IP ownership.

## Verdict

Return one of `monetizable now`, `promising but unproven`, `useful but not monetizable in this form`, or `structurally weak`. Include the weakest link, confidence, disconfirming evidence, next authorized experiment, and expected compounding residue.

