# Edge Selection Protocol

Use this protocol to choose a specialization or compare candidate paths. The result is a decision about where to run the next bounded experiment, not a permanent identity.

## Establish the game

Collect only decision-relevant constraints, one question at a time: desired life and economic outcome; time horizon and weekly capacity; geographic, credential, ethical, health, capital, and risk constraints; existing skills, access, reputation, relationships, data, tools, and distribution; evidence of sustained energy; minimum acceptable income; and maximum proof latency. Treat claimed strengths as hypotheses until attached to evidence.

## Generate decision territories

Convert broad fields into 3–5 narrow territories:

> For `[beneficiary]` facing `[recurring costly situation]`, decide or execute `[specific action]` using `[hard-to-acquire inputs]` to improve `[observable outcome]` within `[time horizon]`.

Reject territories whose outcome is purely subjective, whose feedback is inaccessible, or whose decision cannot be practiced without unacceptable risk. Avoid occupational labels. “AI consultant” is a label; “diagnose and reduce hallucination-driven support failures in regulated customer-service deployments” is a territory.

## Verify the market now

When market value affects the choice, research current conditions. Seek at least two independent signal types:

- Actual purchases, budgets, contracts, or price points
- Repeated buyer complaints tied to cost, risk, delay, or lost revenue
- Current regulation or technology changes forcing action
- Existing alternatives and evidence of their shortcomings
- Hiring or contracting behavior with explicit responsibilities
- First-party interviews or observed workflow data

Search volume, social excitement, course sales, and generic salary pages are weak signals. Use them only as leads. Identify the user, beneficiary, economic buyer, budget owner, blocker, and incumbent alternative separately. If no plausible payer exists, call it useful but not currently monetizable.

## Apply hard gates

Kill or park a territory when any decisive condition holds:

- The problem is not costly, urgent, frequent, or strategically important to anyone able to pay.
- The outcome cannot be observed within the user's runway.
- The user cannot gain legal and ethical access to cases, feedback, or buyers.
- The minimum credible proof requires credentials, capital, or time the user will not obtain.
- The proposed advantage is fully available from public information and easy tooling.
- Automation or platform dependence destroys the proposed value faster than the user can build proof.
- The work conflicts with the user's non-negotiable values or sustainable capacity.

Do not average a fatal gate into an attractive total score.

## Compare surviving candidates

Evaluate each dimension as `strong`, `uncertain`, or `weak`, and attach evidence plus confidence:

- **Value:** magnitude, frequency, budget, urgency, and attributable outcome value
- **Learning position:** case access, feedback speed, interventions, and excellent comparison standards
- **Asymmetry:** unfair access, complementary skills, proprietary instruments, trust, distribution, and retained assets
- **Durability:** copyability, substitution, regime, platform, credential, and regulatory risk
- **Fit:** demonstrated aptitude, sustainable energy under unpleasant realities, lifestyle, risk, and opportunity cost

Scores summarize evidence; they do not create it. Show unknowns explicitly. Prefer a candidate with one testable uncertainty over one supported by many attractive assumptions.

## Search for the wedge

Choose a wedge where the user can reach consequence quickly: a neglected segment, expensive handoff between disciplines, new regulatory or technological constraint, diagnostic bottleneck, proprietary measurement, or intersection where existing capabilities eliminate coordination cost.

The wedge should provide cases, feedback, proof, buyer access, and an owned artifact. It may later expand; do not assume it will.

## Decide

Return:

1. The strongest decision territory and why it survives
2. The strongest rejected alternative and its fatal weakness
3. The current asymmetric advantage, if any
4. The missing advantage that must be manufactured
5. The smallest live experiment capable of invalidating the thesis
6. What the experiment will leave behind even if the thesis fails

If evidence is insufficient, choose `bounded test`, not `pursue`.

